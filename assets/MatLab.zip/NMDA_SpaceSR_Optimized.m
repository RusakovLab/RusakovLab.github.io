function NMDA_SpaceSR_Optimized()
%NMDA_SPACESR_OPTIMIZED Analyse master-simulation glutamate data with NMDA.
% This version reduces interpolation overhead while preserving the model,
% solver tolerances, input timing, output resolution, and plotted states.
% New datasets are paired with SimulationMetadata files containing their
% exact time points, radial shells, and physical units. Legacy datasets
% without metadata remain supported through manual fallback parameters.

%% User parameters

% All parameters come from the shared InputParametersSR definition.
[~, ~, ~, ~, ~, ~, ~, NmdaPar, Analysis] = InputParametersSR();
LEGACY_MASTER_TOTAL_TIME_MS = NmdaPar.LegacyMasterTotalTime_ms;      % used only when SimulationMetadata is absent
NMDA_TOTAL_TIME_MS = NmdaPar.TotalTime_ms;                          % total duration of receptor dynamics
LEGACY_MAXIMUM_DISTANCE_M = NmdaPar.LegacyMaximumDistance_um * 1e-6; % plotting range used only for legacy data
DATA_FOLDER_NAME = Analysis.DataFolderName;

%% Locate and load data

scriptFolder = fileparts(mfilename('fullpath'));
dataFolder = fullfile(scriptFolder,DATA_FOLDER_NAME);

if ~isfolder(dataFolder)
    error('Data directory does not exist: %s',dataFolder);
end

fprintf('Loading glutamate distribution files...\n');
[initialDistribution,fileCount,metadata] = ...
    load_distribution_files(dataFolder);

if fileCount == 0
    error('No compatible DistanceFree*.txt files found in: %s',dataFolder);
end

distanceBinCount = size(initialDistribution,1);
glutamateTimeBinCount = size(initialDistribution,2)-1;

if glutamateTimeBinCount < 1
    error('DistanceFree must contain one distance column and time columns.');
end

%% Resolve coordinates and shell volumes

if ~isempty(metadata)
    validate_metadata(metadata,distanceBinCount,glutamateTimeBinCount);

    masterTotalTime_ms = metadata.TotalTime_ms;
    glutamateTime_ms = reshape(metadata.TimePoints_ms,1,[]);
    shellVolumes_um3 = reshape(metadata.ShellVolume_um3,[],1);
    distanceVector_um = reshape(metadata.OuterRadius_um,[],1);

    fprintf('Using SimulationMetadata for run %s.\n',metadata.RunID);
else
    masterTotalTime_ms = LEGACY_MASTER_TOTAL_TIME_MS;
    glutamateTime_ms = ...
        (1:glutamateTimeBinCount)* ...
        (masterTotalTime_ms/glutamateTimeBinCount);

    distanceEdgesNormalised = ...
        (1:distanceBinCount+1)/distanceBinCount;
    shellVolumes_um3 = ...
        calculate_legacy_spherical_volumes(distanceEdgesNormalised);
    distanceVector_um = linspace( ...
        0,LEGACY_MAXIMUM_DISTANCE_M*1e6,distanceBinCount)';

    warning(['SimulationMetadata was not found. Using legacy duration ' ...
        '%.6g ms and legacy shell geometry.'],masterTotalTime_ms);
end

if NMDA_TOTAL_TIME_MS < masterTotalTime_ms
    error('NMDA_TOTAL_TIME_MS must be no shorter than the master duration.');
end

fprintf('Averaged %d compatible files.\n',fileCount);
fprintf('Detected %d spatial bins and %d glutamate time bins.\n', ...
    distanceBinCount,glutamateTimeBinCount);
fprintf('Master duration: %.6g ms; NMDA duration: %.6g ms.\n', ...
    masterTotalTime_ms,NMDA_TOTAL_TIME_MS);

%% Convert molecule counts to micromoles per litre

moleculeCount = initialDistribution(:,2:end);
avogadroNumber = Analysis.AvogadroNumber;
moleculePerUm3To_uM = 1e21/avogadroNumber;

glutamateConcentration_uM = ...
    moleculePerUm3To_uM .* moleculeCount ./ shellVolumes_um3;

plot_initial_distribution( ...
    glutamateConcentration_uM,glutamateTime_ms,distanceVector_um);

%% NMDA receptor dynamics

nmdaOutputTime_ms = linspace( ...
    0,NMDA_TOTAL_TIME_MS,glutamateTimeBinCount);
selectedState = zeros(distanceBinCount,glutamateTimeBinCount);
odeOptions = odeset('RelTol',Analysis.ODE_RelTol,'AbsTol',Analysis.ODE_AbsTol*ones(1,5));

fprintf('Starting NMDA receptor dynamics simulation...\n');

for distanceIndex = 1:distanceBinCount
    if mod(distanceIndex,10) == 0 || distanceIndex == distanceBinCount
        fprintf('Processing spatial bin %d/%d\n', ...
            distanceIndex,distanceBinCount);
    end

    glutamateTrace_uM = glutamateConcentration_uM(distanceIndex,:);
    [nmdaInputTime_ms,glutamateInput_uM] = ...
        extend_glutamate_input_with_zeros( ...
        glutamateTime_ms,glutamateTrace_uM,NMDA_TOTAL_TIME_MS);

    odeFunction = @(t,y) NMDA_basic( ...
        t,y,glutamateInput_uM,nmdaInputTime_ms,NMDA_TOTAL_TIME_MS);

    % Request the required output times directly from ode45. The solver
    % still selects its own internal steps, but no second interpolation of
    % the receptor solution is required.
    [receptorTime_ms,receptorStates] = ode45( ...
        odeFunction,nmdaOutputTime_ms,[1 0 0 0 0],odeOptions);

    % State 4 is the open NMDA receptor state.
    selectedState(distanceIndex,:) = receptorStates(:,4)';
end

fprintf('NMDA simulation completed.\n');

plot_nmda_states(receptorTime_ms,receptorStates);
plot_binding_heatmap( ...
    selectedState,nmdaOutputTime_ms,distanceVector_um);

fprintf('Analysis completed successfully.\n');
end


function [distribution,fileCount,referenceMetadata] = ...
        load_distribution_files(folderPath)
%LOAD_DISTRIBUTION_FILES Load only the newest complete master run.
% A complete new-format run contains matching DistanceFree and
% SimulationMetadata files. If none exists, load the newest legacy file.

fileList = dir(fullfile(folderPath,'DistanceFree*.txt'));
distribution = [];
fileCount = 0;
referenceMetadata = [];

if isempty(fileList)
    return;
end

[~,newestOrder] = sort([fileList.datenum],'descend');
fileList = fileList(newestOrder);
selectedFileIndex = [];
selectedMetadataPath = '';

for fileIndex = 1:numel(fileList)
    [~,baseName] = fileparts(fileList(fileIndex).name);
    runID = strtrim(erase(baseName,'DistanceFree'));
    candidateMetadataPath = fullfile( ...
        folderPath,sprintf('SimulationMetadata %s.mat',runID));

    if isfile(candidateMetadataPath)
        selectedFileIndex = fileIndex;
        selectedMetadataPath = candidateMetadataPath;
        break;
    end
end

if isempty(selectedFileIndex)
    selectedFileIndex = 1;
    warning(['No complete metadata-paired run was found. Loading only ' ...
        'the newest legacy DistanceFree file.']);
end

selectedFile = fileList(selectedFileIndex);
selectedDataPath = fullfile(folderPath,selectedFile.name);
fprintf('Loading one master run: %s\n',selectedFile.name);
distribution = readmatrix(selectedDataPath);

if isempty(distribution) || ~isnumeric(distribution)
    error('Selected DistanceFree file is empty or non-numeric: %s', ...
        selectedDataPath);
end

if ~isempty(selectedMetadataPath)
    metadataContainer = load(selectedMetadataPath,'Metadata');
    if ~isfield(metadataContainer,'Metadata')
        error('Metadata file does not contain a Metadata structure: %s', ...
            selectedMetadataPath);
    end
    referenceMetadata = metadataContainer.Metadata;

    if isfield(referenceMetadata,'DistanceFreeFile') && ...
            ~strcmp(referenceMetadata.DistanceFreeFile,selectedFile.name)
        error('Metadata does not reference the selected DistanceFree file.');
    end
end

fileCount = 1;
end

function isCompatible = metadata_is_compatible(firstMetadata,secondMetadata)
%METADATA_IS_COMPATIBLE Check fields required before averaging datasets.

requiredFields = {'FormatVersion','TotalTime_ms','TimeBins', ...
    'DistanceBins','TimePoints_ms','RadialEdges_nm', ...
    'ShellVolume_um3'};

isCompatible = all(isfield(firstMetadata,requiredFields)) && ...
    all(isfield(secondMetadata,requiredFields));

if ~isCompatible
    return;
end

numericFields = {'TotalTime_ms','TimeBins','DistanceBins', ...
    'TimePoints_ms','RadialEdges_nm','ShellVolume_um3'};

for fieldIndex = 1:numel(numericFields)
    fieldName = numericFields{fieldIndex};
    firstValue = firstMetadata.(fieldName);
    secondValue = secondMetadata.(fieldName);

    if ~isequal(size(firstValue),size(secondValue)) || ...
            any(abs(firstValue(:)-secondValue(:)) > ...
            1e-10*max(1,max(abs(firstValue(:)))))
        isCompatible = false;
        return;
    end
end
end


function validate_metadata(metadata,distanceBinCount,timeBinCount)
%VALIDATE_METADATA Validate dimensions used by the receptor analysis.

requiredFields = {'FormatVersion','RunID','TotalTime_ms','TimeBins', ...
    'DistanceBins','TimePoints_ms','InnerRadius_um', ...
    'OuterRadius_um','ShellVolume_um3'};

if ~all(isfield(metadata,requiredFields))
    error('SimulationMetadata is missing one or more required fields.');
end

if metadata.FormatVersion ~= 1
    error('Unsupported SimulationMetadata format version: %g.', ...
        metadata.FormatVersion);
end

if metadata.DistanceBins ~= distanceBinCount || ...
        metadata.TimeBins ~= timeBinCount
    error('SimulationMetadata dimensions do not match DistanceFree.');
end

if numel(metadata.TimePoints_ms) ~= timeBinCount || ...
        numel(metadata.InnerRadius_um) ~= distanceBinCount || ...
        numel(metadata.OuterRadius_um) ~= distanceBinCount || ...
        numel(metadata.ShellVolume_um3) ~= distanceBinCount
    error('SimulationMetadata coordinate lengths do not match DistanceFree.');
end

if any(metadata.ShellVolume_um3 <= 0) || ...
        any(diff(metadata.TimePoints_ms) <= 0)
    error('SimulationMetadata contains invalid shell volumes or time points.');
end
end


function [extendedTime_ms,extendedConcentration_uM] = ...
        extend_glutamate_input_with_zeros( ...
        glutamateTime_ms,glutamateConcentration_uM,nmdaTotalTime_ms)
%EXTEND_GLUTAMATE_INPUT_WITH_ZEROS Preserve input samples, then set zero.

if numel(glutamateTime_ms) ~= numel(glutamateConcentration_uM)
    error('Glutamate time and concentration vectors must have equal length.');
end

if numel(glutamateTime_ms) > 1
    inputTimeStep_ms = median(diff(glutamateTime_ms));
else
    inputTimeStep_ms = glutamateTime_ms(1);
end

if inputTimeStep_ms <= 0
    error('Glutamate time step must be positive.');
end

% Use the first measured value over the unsampled initial interval.
extendedTime_ms = [0,reshape(glutamateTime_ms,1,[])];
extendedConcentration_uM = [ ...
    glutamateConcentration_uM(1), ...
    reshape(glutamateConcentration_uM,1,[])];

firstZeroTime_ms = min( ...
    glutamateTime_ms(end)+inputTimeStep_ms,nmdaTotalTime_ms);

% Linear interpolation needs only the first zero sample and the final
% endpoint. Intermediate zero samples carry no additional information.
if firstZeroTime_ms < nmdaTotalTime_ms
    tailTime_ms = [firstZeroTime_ms,nmdaTotalTime_ms];
else
    tailTime_ms = nmdaTotalTime_ms;
end

% Avoid a duplicate time point when the final glutamate sample already
% coincides with the end of the receptor simulation.
if tailTime_ms(1) <= extendedTime_ms(end)
    tailTime_ms = tailTime_ms(tailTime_ms > extendedTime_ms(end));
end

extendedTime_ms = [extendedTime_ms,tailTime_ms];
extendedConcentration_uM = [ ...
    extendedConcentration_uM,zeros(size(tailTime_ms))];
end


function volumes = calculate_legacy_spherical_volumes(distanceEdges)
%CALCULATE_LEGACY_SPHERICAL_VOLUMES Reproduce the old shell geometry.

outerRadii = 2*distanceEdges(2:end)';
innerRadii = 2*distanceEdges(1:end-1)';
volumes = (4/3)*pi*(outerRadii.^3-innerRadii.^3);
end


function plot_initial_distribution(concentration_uM,timeVector_ms,distanceVector_um)
%PLOT_INITIAL_DISTRIBUTION Plot concentration in micromoles per litre.

plotData_uM = concentration_uM;
plotData_uM(plotData_uM <= 0) = NaN;
positiveConcentrations = sort(plotData_uM(isfinite(plotData_uM)));

if isempty(positiveConcentrations)
    error('The selected DistanceFree run contains no positive glutamate concentration.');
end

maximumConcentration_uM = positiveConcentrations(end);
lowerColourLimit_uM = max( ...
    positiveConcentrations(1),maximumConcentration_uM*1e-4);

figure(1);
clf;
imagesc(timeVector_ms,distanceVector_um,plotData_uM);
axis xy;
set(gca,'ColorScale','log','FontSize',12);
clim([lowerColourLimit_uM maximumConcentration_uM]);
colourBar = colorbar;
colourBar.Label.String = 'Glutamate concentration (\muM)';
title('Glutamate Concentration Distribution');
xlabel('Time (ms)');
ylabel('Distance (\mum)');
end

function plot_nmda_states(time_ms,states)
%PLOT_NMDA_STATES Plot the five NMDA state variables.

stateNames = {'Unbound','Singly Bound','Doubly Bound (Closed)', ...
    'Open','Desensitized'};

figure(2);
clf;

for stateIndex = 1:5
    subplot(2,3,stateIndex);
    plot(time_ms,states(:,stateIndex),'LineWidth',2);
    title(sprintf('State %d: %s',stateIndex,stateNames{stateIndex}));
    xlabel('Time (ms)');
    ylabel('Probability');
    grid on;
    set(gca,'FontSize',10);
end

sgtitle('NMDA Receptor State Evolution', ...
    'FontSize',14,'FontWeight','bold');
end


function plot_binding_heatmap(bindingData,timeVector_ms,distanceVector_um)
%PLOT_BINDING_HEATMAP Plot the selected NMDA state over space and time.

figure(3);
clf;
contourf(timeVector_ms,distanceVector_um, ...
    bindingData,20,'LineColor','none');
colorbar;
clim([0 0.4]);
title('NMDA Receptor Open-State Probability');
xlabel('Time (ms)');
ylabel('Distance (\mum)');
set(gca,'FontSize',12);
colormap('jet');

text(0.02,0.98,sprintf('Max: %.3f',max(bindingData(:))), ...
    'Units','normalized','VerticalAlignment','top', ...
    'BackgroundColor','white','EdgeColor','black');
end



