% DIFFUSIONGLUTAMATEBALLS
% Monte Carlo simulation of glutamate diffusion, obstacle interactions,
% adhesion, uptake, scheduled release events, and radial spillover.
% Spatial coordinates are in nm and simulation time is in ms.

clear;
clc;
rng('shuffle') % set seeds the random number generator based on the current time

% Load the complete parameter set and validate derived configuration values.
[BasicParameters, Balls, ComputationSet, Cleft, SizeCube, Adhesion]=InputParametersSR();
DistanceBins = ComputationSet.DistanceBins;
TimeBins = ComputationSet.TimeBins;
if ~isscalar(DistanceBins) || DistanceBins < 1 || fix(DistanceBins) ~= DistanceBins
    error('ComputationSet.DistanceBins must be a positive integer.');
end
if ~isscalar(TimeBins) || TimeBins < 1 || fix(TimeBins) ~= TimeBins
    error('ComputationSet.TimeBins must be a positive integer.');
end
if ~isscalar(BasicParameters.SaveReceptorInputData) || ...
        ~(islogical(BasicParameters.SaveReceptorInputData) || ...
        (isnumeric(BasicParameters.SaveReceptorInputData) && ...
        any(BasicParameters.SaveReceptorInputData == [0 1])))
    error('BasicParameters.SaveReceptorInputData must be true or false.');
end
SaveReceptorInputData = logical(BasicParameters.SaveReceptorInputData);
if ~isscalar(Cleft.SynapticEnvelopeRadius) || ...
        ~isfinite(Cleft.SynapticEnvelopeRadius) || ...
        Cleft.SynapticEnvelopeRadius < Cleft.RadiusofCleft
    error(['Cleft.SynapticEnvelopeRadius must be finite and no smaller ' ...
        'than Cleft.RadiusofCleft.']);
end

%********************************************************
% Frequently used scalar aliases derived from the parameter structures.

np = BasicParameters.NumberOfParticles;              % Number of p
charge = BasicParameters.charge;             % Charge of particles
TotalTime = BasicParameters.TotalTime;                  % Time of computation in ms 0.21
Numbersphere = BasicParameters.Numbersphere;          % b=0.3 13000 b=0.8 40000
BeginTime = BasicParameters.BeginTime*BasicParameters.TotalTime;       % Offset  to compute the diffusion coefficient in ms 0.015
EndTime = BasicParameters.EndTime*BasicParameters.TotalTime;         % End time to compute the diffusion coefficient in ms 0.02
Trials = BasicParameters.Trials;                  % Number of Runs to compute the statistics

ReleaseTimes = BasicParameters.ReleaseTimes;
ReleaseFractions = BasicParameters.ReleaseFractions;
if ~isvector(ReleaseTimes) || ~isvector(ReleaseFractions) || ...
        isempty(ReleaseTimes) || numel(ReleaseTimes) ~= numel(ReleaseFractions)
    error('ReleaseTimes and ReleaseFractions must be non-empty vectors of equal length.');
end
ReleaseTimes = reshape(ReleaseTimes,1,[]);
ReleaseFractions = reshape(ReleaseFractions,1,[]);
if any(~isfinite(ReleaseTimes)) || ReleaseTimes(1) ~= 0 || ...
        any(diff(ReleaseTimes) <= 0) || any(ReleaseTimes > TotalTime)
    error(['ReleaseTimes must start at 0, be finite and strictly increasing, ' ...
        'and not exceed TotalTime.']);
end
if any(~isfinite(ReleaseFractions)) || any(ReleaseFractions <= 0) || ...
        abs(sum(ReleaseFractions)-1) > 1e-12
    error('ReleaseFractions must be positive, finite, and sum to 1.');
end

fileIDStat = fopen('StatisticOut.txt','w'); % summary diffusion statistics output


%**************************************************************************
NumberControlParticles = Balls.OccupancySampleCount;
if ~isscalar(NumberControlParticles) || NumberControlParticles < 1 || ...
        fix(NumberControlParticles) ~= NumberControlParticles
    error('Balls.OccupancySampleCount must be a positive integer.');
end
DistanceX = SizeCube.Size;  % in um, the size modulo the spatial region, x-coordinate, in which the balls are placed./ // Betta 0.3 1700

%***********************************************
% Size of visualization area
AxisSize=SizeCube.AxisSize; %maximum size axis y and z for visualization of diffusion in micrometers
SizeOfaxisX = 1; % Xlim= SizeOfaxisX * AxisSize

% *************************************************************************
% Adhesive parameters
DigitalTimeofAdhesion = round(Adhesion.TimeOfDeAdhesion/ComputationSet.GTimeStep);


r = rand(np,1);
%**************************************************************************
ProbabilityofUptaken = 1-BasicParameters.UnboundProb; %0.5; 1 - is NOT UNBOUND

% Generate integer de-adhesion durations from a bounded normal distribution.
% Mean = 4000 steps, standard deviation = 2000 steps, bounds = 1000:7000 steps.
DeAdhesionDurationSteps = round(4000 + 2000*randn(1,np));
DeAdhesionDurationSteps = min(max(DeAdhesionDurationSteps,1000),7000);


DigitalTimeofAdhesionStochastic = zeros(np,1);
for i = 1:np
    if r(i) < ProbabilityofUptaken
        DigitalTimeofAdhesionStochastic(i) = 0;
    else
        DigitalTimeofAdhesionStochastic(i) = DeAdhesionDurationSteps(i);
    end
end
%**************************************************************************

NumberTimeInteraction=round(TotalTime/ComputationSet.GTimeStep);  % Number of step time for diffusion calculations
if ~isscalar(BasicParameters.GraphicsUpdateEveryNSteps) || ...
        BasicParameters.GraphicsUpdateEveryNSteps < 1 || ...
        fix(BasicParameters.GraphicsUpdateEveryNSteps) ~= BasicParameters.GraphicsUpdateEveryNSteps
    error('BasicParameters.GraphicsUpdateEveryNSteps must be a positive integer.');
end
GraphicsUpdateEvery = BasicParameters.GraphicsUpdateEveryNSteps;
if ~isscalar(BasicParameters.ShowObstacleBalls) || ...
        ~(islogical(BasicParameters.ShowObstacleBalls) || ...
        (isnumeric(BasicParameters.ShowObstacleBalls) && ...
        any(BasicParameters.ShowObstacleBalls == [0 1])))
    error('BasicParameters.ShowObstacleBalls must be true or false.');
end
ShowObstacleBalls = logical(BasicParameters.ShowObstacleBalls);
if ~(ischar(BasicParameters.ObstacleBallDisplayMode) || ...
        (isstring(BasicParameters.ObstacleBallDisplayMode) && ...
        isscalar(BasicParameters.ObstacleBallDisplayMode)))
    error('BasicParameters.ObstacleBallDisplayMode must be text.');
end
ObstacleBallDisplayMode = lower(char(BasicParameters.ObstacleBallDisplayMode));
if ~any(strcmp(ObstacleBallDisplayMode, ...
        {'adhesive','nonadhesive','both'}))
    error(['BasicParameters.ObstacleBallDisplayMode must be ' ...
        '''adhesive'', ''nonadhesive'', or ''both''.']);
end
if ~isnumeric(BasicParameters.AdhesiveBallColor) || ...
        ~isequal(size(BasicParameters.AdhesiveBallColor),[1 3]) || ...
        any(~isfinite(BasicParameters.AdhesiveBallColor)) || ...
        any(BasicParameters.AdhesiveBallColor < 0 | ...
        BasicParameters.AdhesiveBallColor > 1)
    error('BasicParameters.AdhesiveBallColor must be a finite 1-by-3 RGB vector in [0,1].');
end
if ~isnumeric(BasicParameters.NonAdhesiveBallColor) || ...
        ~isequal(size(BasicParameters.NonAdhesiveBallColor),[1 3]) || ...
        any(~isfinite(BasicParameters.NonAdhesiveBallColor)) || ...
        any(BasicParameters.NonAdhesiveBallColor < 0 | ...
        BasicParameters.NonAdhesiveBallColor > 1)
    error('BasicParameters.NonAdhesiveBallColor must be a finite 1-by-3 RGB vector in [0,1].');
end
AdhesiveBallColor = BasicParameters.AdhesiveBallColor;
NonAdhesiveBallColor = BasicParameters.NonAdhesiveBallColor;
% Bound-particle removal and loss of ball adhesiveness are independent.
% This hazard irreversibly removes bound glutamate particles.
if BasicParameters.UseExponentialDecay
    if BasicParameters.TimeDecay <= 0
        error('BasicParameters.TimeDecay must be positive.');
    end
    PBoundRemovalStep = 1-exp(-ComputationSet.GTimeStep/BasicParameters.TimeDecay);
else
    PBoundRemovalStep = 0;
end

% This separate hazard converts adhesive balls to non-adhesive balls
% without changing their geometrical volume.
if ~isscalar(Balls.UseAdhesionDecay) || ...
        ~(islogical(Balls.UseAdhesionDecay) || ...
        (isnumeric(Balls.UseAdhesionDecay) && ...
        any(Balls.UseAdhesionDecay == [0 1])))
    error('Balls.UseAdhesionDecay must be true or false.');
end
if Balls.UseAdhesionDecay
    if ~isscalar(Balls.AdhesionDecayTime) || ...
            ~isfinite(Balls.AdhesionDecayTime) || ...
            Balls.AdhesionDecayTime <= 0
        error('Balls.AdhesionDecayTime must be a finite positive value in ms.');
    end
    PAdhesionLossStep = ...
        1-exp(-ComputationSet.GTimeStep/Balls.AdhesionDecayTime);
else
    PAdhesionLossStep = 0;
end
Betta=zeros(1,Trials);



for IterTrial = 1:Trials % number of trials to compute the mean value of diffusion coefficient
    CreatMatrixAverage = 0.01;
    IndexMatrix = 1;
    Time=0:ComputationSet.GTimeStep:TotalTime;
    if strcmp(BasicParameters.ShowGraphics,'y')
        figure(1);
        clf;
        set(gcf,'Color','w');

        % Keep all three axes fixed throughout the animation.
        set(gca,'XLim',[-SizeCube.AxisSize SizeCube.AxisSize], ...
            'YLim',[-SizeCube.AxisSize SizeCube.AxisSize], ...
            'ZLim',[-SizeCube.AxisSize SizeCube.AxisSize], ...
            'XLimMode','manual', ...
            'YLimMode','manual','ZLimMode','manual');
        daspect([1 1 1]);
        grid on;
        view(3);
        xlabel('X (nm)');
        ylabel('Y (nm)');
        zlabel('Z (nm)');
        hold on;
    end
    % Initialise ball geometry. In r, column 1 stores radius in nm and
    % column 2 stores adhesiveness (1 adhesive, 0 non-adhesive).
    [x,y,z] = sphere;
    r=zeros(Numbersphere,2);
    xd=zeros(Numbersphere,1);yd=zeros(Numbersphere,1);zd=zeros(Numbersphere,1);
    % determination of initial vector of diffusion coefficient
    DifCoefTotal=zeros(1);
    DifCoefTotalX=zeros(1);
    DifCoef=zeros(1,NumberTimeInteraction+1);
    DifCoefX=zeros(1,NumberTimeInteraction+1);
    % seed number
    TotalNumberinteration=1;

    % rout of computaion in time
    for NumberIteretion = 1:  TotalNumberinteration
        requiredPositionBytes = 3*(NumberTimeInteraction+1)*np*8;
        maxPositionMemoryBytes = 8*1024^3;
        if requiredPositionBytes > maxPositionMemoryBytes
            error('Position arrays require %.2f GB; reduce np or TotalTime, or increase GTimeStep.', requiredPositionBytes/1024^3);
        end
        x_par = zeros(NumberTimeInteraction+1,np);
        y_par = zeros(NumberTimeInteraction+1,np);
        z_par = zeros(NumberTimeInteraction+1,np);

        % Particle-state matrix:
        % Stak(:,1): 1 free; >1 bound and counting residence steps.
        % Stak(:,2): reserved auxiliary state; currently unused and kept at 0.
        % Stak(:,3): 1 active; 0 unreleased or irreversibly removed.
        Stak = zeros(np,3);
        Stak(:,1) = 1;

        % Assign every particle to one release while preserving the requested
        % fractions as closely as possible for an integer particle count.
        rawReleaseCounts = np*ReleaseFractions;
        ReleaseCounts = floor(rawReleaseCounts);
        remainingParticles = np-sum(ReleaseCounts);
        [~,remainderOrder] = sort(rawReleaseCounts-ReleaseCounts,'descend');
        ReleaseCounts(remainderOrder(1:remainingParticles)) = ...
            ReleaseCounts(remainderOrder(1:remainingParticles))+1;

        ParticleReleaseTime = nan(np,1);
        releasePermutation = randperm(np);
        releaseStartIndex = 1;
        for ReleaseIndex = 1:numel(ReleaseTimes)
            releaseEndIndex = releaseStartIndex+ReleaseCounts(ReleaseIndex)-1;
            assignedParticles = ...
                releasePermutation(releaseStartIndex:releaseEndIndex);
            ParticleReleaseTime(assignedParticles) = ReleaseTimes(ReleaseIndex);
            releaseStartIndex = releaseEndIndex+1;
        end

        HasBeenReleased = ParticleReleaseTime <= 0;
        Stak(:,3) = double(HasBeenReleased);
switch lower(BasicParameters.ReleaseSource)
    case 'astrocyte'
        % Release particles from an astrocyte surface patch directly into extracellular space.
        % Define the astrocyte parameters in nanometers
        astrocyte_radius = BasicParameters.AstrocyteRadius;
        astrocyte_center_distance = BasicParameters.AstrocyteCenterDistance;
        release_patch_radius = BasicParameters.ReleasePatchRadius;
        if astrocyte_radius <= 0 || astrocyte_center_distance <= 0
            error('AstrocyteRadius and AstrocyteCenterDistance must be positive.');
        end
        if release_patch_radius <= 0 || release_patch_radius > astrocyte_radius
            error('ReleasePatchRadius must be positive and no larger than AstrocyteRadius.');
        end
        % Store the primary astrocyte as the first real sphere.
        r(1,1) = astrocyte_radius;
        r(1,2) = 1;
        xd(1) = 0;
        yd(1) = astrocyte_center_distance;
        zd(1) = 0;
        FirstExtracellularBallIndex = 2;


        % Define the center of the astrocyte sphere
        % The astrocyte centre is offset from the extracellular release origin.
        astrocyte_center = [0, astrocyte_center_distance, 0];

        % Calculate the direction vector from the astrocyte center to the origin
        direction_to_origin = -astrocyte_center / norm(astrocyte_center);

        % Generate random positions on the release patch
        % The patch is a small region on the astrocyte surface, facing the origin
        theta = 2 * pi * rand(np, 1); % Azimuthal angle (random around the patch)
        phi_max = asin(release_patch_radius / astrocyte_radius); % Maximum polar angle for the patch
        phi = phi_max * (2 * rand(np, 1) - 1); % Polar angle (random within the patch)

        % Convert spherical coordinates to Cartesian coordinates relative to the astrocyte center
        x_patch = astrocyte_radius * sin(phi) .* cos(theta);
        y_patch = astrocyte_radius * sin(phi) .* sin(theta);
        z_patch = astrocyte_radius * cos(phi);

        % Rotate the patch to face the origin
        % Define the initial alignment of the patch (along the z-axis)
        initial_direction = [0; 0; 1];
        direction_to_origin = direction_to_origin(:);

        % Toolbox-free Rodrigues rotation matrix
        rotation_axis = cross(initial_direction, direction_to_origin);
        sin_angle = norm(rotation_axis);
        cos_angle = dot(initial_direction, direction_to_origin);

        if sin_angle < 1e-12
            if cos_angle > 0
                rotation_matrix = eye(3);
            else
                % Vectors are opposite: rotate 180 degrees around the x-axis
                rotation_matrix = [1 0 0; 0 -1 0; 0 0 -1];
            end
        else
            rotation_axis = rotation_axis / sin_angle;
            K = [0,                 -rotation_axis(3),  rotation_axis(2);
                 rotation_axis(3),  0,                -rotation_axis(1);
                -rotation_axis(2),  rotation_axis(1),  0];

            rotation_matrix = eye(3) ...
                            + sin_angle*K ...
                            + (1-cos_angle)*(K*K);
        end

        % Apply the rotation to the patch positions
        patch_positions = (rotation_matrix * [x_patch, y_patch, z_patch]')';

        % Translate the patch positions to the global coordinate system
        x_par(1,:) = patch_positions(:,1) + astrocyte_center(1);
        y_par(1,:) = patch_positions(:,2) + astrocyte_center(2);
        z_par(1,:) = patch_positions(:,3) + astrocyte_center(3);

        % Ensure the particles are on the surface of the astrocyte
        % (Optional: Add a small random perturbation to simulate initial diffusion)
        perturbation = 10; % Small perturbation in nm (10 nm)
        x_par(1,:) = x_par(1,:) + perturbation * (rand(1, np) - 0.5);
        y_par(1,:) = y_par(1,:) + perturbation * (rand(1, np) - 0.5);
        z_par(1,:) = z_par(1,:) + perturbation * (rand(1, np) - 0.5);
        if strcmp(BasicParameters.ShowGraphics,'y')
            % Plot the astrocyte sphere
            [x_sphere, y_sphere, z_sphere] = sphere(50);
            x_sphere = astrocyte_radius * x_sphere + astrocyte_center(1);
            y_sphere = astrocyte_radius * y_sphere + astrocyte_center(2);
            z_sphere = astrocyte_radius * z_sphere + astrocyte_center(3);
            surf(x_sphere, y_sphere, z_sphere, 'FaceAlpha', 0.3, 'EdgeColor', 'none');
            hold on;

            % Plot the release patch

            xlabel('X (nm)');
            ylabel('Y (nm)');
            zlabel('Z (nm)');
            title('Astrocyte release into extracellular space');
        end


    case 'synapse'
        % Point release at the centre of the cylindrical synaptic cleft.
        x_par(1,:) = 0;
        y_par(1,:) = 0;
        z_par(1,:) = 0;

        % No sphere is reserved in this branch. All sphere-array entries
        % are available for real extracellular obstacles.
        FirstExtracellularBallIndex = 1;

        if strcmp(BasicParameters.ShowGraphics,'y')
            membraneAngle = linspace(0,2*pi,96);
            membraneRadius = linspace(0,Cleft.RadiusofCleft,24);
            [membraneTheta,membraneR] = meshgrid(membraneAngle,membraneRadius);
            membraneX = membraneR.*cos(membraneTheta);
            membraneY = membraneR.*sin(membraneTheta);
            upperMembraneZ = (Cleft.CleftWidth/2)*ones(size(membraneX));
            lowerMembraneZ = -(Cleft.CleftWidth/2)*ones(size(membraneX));

            surf(membraneX,membraneY,upperMembraneZ, ...
                'FaceColor',[0.35 0.55 0.85],'FaceAlpha',0.18,'EdgeColor','none');
            hold on;
            surf(membraneX,membraneY,lowerMembraneZ, ...
                'FaceColor',[0.35 0.55 0.85],'FaceAlpha',0.18,'EdgeColor','none');
            plot3(Cleft.RadiusofCleft*cos(membraneAngle), ...
                Cleft.RadiusofCleft*sin(membraneAngle), ...
                (Cleft.CleftWidth/2)*ones(size(membraneAngle)), ...
                'Color',[0.2 0.35 0.65],'LineWidth',1.2);
            plot3(Cleft.RadiusofCleft*cos(membraneAngle), ...
                Cleft.RadiusofCleft*sin(membraneAngle), ...
                -(Cleft.CleftWidth/2)*ones(size(membraneAngle)), ...
                'Color',[0.2 0.35 0.65],'LineWidth',1.2);
            title('Point release in the open synaptic cleft');
        end

    otherwise
        error('BasicParameters.ReleaseSource must be ''astrocyte'' or ''synapse''.');
end

        TimeOfAdhesive = zeros(1, np);
        Distance=zeros(1);
        DiffusionEstimateSum3D=0;
        DiffusionEstimateSumX=0;
        DifCoef=zeros(1);
        NumberParticles=zeros(1,NumberTimeInteraction+1);
        NumberSpillover=zeros(1,NumberTimeInteraction+1);
        FractionSpillover=zeros(1,NumberTimeInteraction+1);
        NumberFreeSpillover=zeros(1,NumberTimeInteraction+1);
        FractionFreeSpillover=zeros(1,NumberTimeInteraction+1);
        FirstPassageTime=nan(1,np);
        FirstPassageLatency=nan(1,np);
        DifCoefX=zeros(1);
        DifCoefY=zeros(1);
        DifCoefZ=zeros(1);

        
        if ~(strcmpi(Balls.PlacementMode,'overlapping') || ...
                strcmpi(Balls.PlacementMode,'nonoverlapping'))
            error('Balls.PlacementMode must be ''overlapping'' or ''nonoverlapping''.');
        end
        if ~isscalar(Balls.MinimumBallSeparation) || ...
                ~isfinite(Balls.MinimumBallSeparation) || Balls.MinimumBallSeparation < 0
            error('Balls.MinimumBallSeparation must be a finite non-negative value.');
        end
        if ~isscalar(Balls.MaximumPlacementAttempts) || ...
                Balls.MaximumPlacementAttempts < 1 || ...
                fix(Balls.MaximumPlacementAttempts) ~= Balls.MaximumPlacementAttempts
            error('Balls.MaximumPlacementAttempts must be a positive integer.');
        end

        % The primary astrocyte is excluded from the sampled extracellular
        % domain, so only generated extracellular obstacles contribute here.
        SpaceBalls = 0;
        for j = FirstExtracellularBallIndex:Numbersphere
            ballPlaced = false;
            for placementAttempt = 1:Balls.MaximumPlacementAttempts
                xd(j) = DistanceX*(rand()-0.5);
                yd(j) = DistanceX*(rand()-0.5);
                zd(j) = DistanceX*(rand()-0.5);
                r(j,1) = Balls.MinBallRadius + ...
                    rand()*(Balls.MaxBallRadius-Balls.MinBallRadius);

                % Keep the candidate ball outside the source-specific exclusion region.
                if strcmpi(BasicParameters.ReleaseSource,'synapse')
                    sourceClearanceSatisfied = ...
                        sqrt(xd(j)^2+yd(j)^2+zd(j)^2)-r(j,1) >= ...
                        Cleft.SynapticEnvelopeRadius;
                else
                    sourceClearanceSatisfied = ...
                        sqrt((xd(j)-astrocyte_center(1))^2 + ...
                        (yd(j)-astrocyte_center(2))^2 + ...
                        (zd(j)-astrocyte_center(3))^2)-r(j,1) >= ...
                        astrocyte_radius+Cleft.DistanceAstrocyte;
                end
                if ~sourceClearanceSatisfied
                    continue;
                end

                switch lower(Balls.PlacementMode)
                    case 'overlapping'
                        % Standard mode: intersections between extracellular balls are allowed.
                        ballPlaced = true;

                    case 'nonoverlapping'
                        % Optional mode: every surface-to-surface gap must satisfy
                        % Balls.MinimumBallSeparation.
                        centreDistances = sqrt((xd(j)-xd(1:j-1)).^2 + ...
                            (yd(j)-yd(1:j-1)).^2 + ...
                            (zd(j)-zd(1:j-1)).^2);
                        surfaceGaps = centreDistances-r(j,1)-r(1:j-1,1);
                        ballPlaced = all(surfaceGaps >= Balls.MinimumBallSeparation);
                end
                if ballPlaced
                    break;
                end
            end

            if ~ballPlaced
                error(['Unable to place ball %d after %d attempts. Reduce the ' ...
                    'number or size of balls, reduce MinimumBallSeparation, ' ...
                    'or use PlacementMode=''overlapping''.'], ...
                    j,Balls.MaximumPlacementAttempts);
            end

            % Mark a fraction of accepted balls as transporter-positive.
            r(j,2) = double(rand() < Balls.ProbabilityofAstrocytes);
            SpaceBalls = SpaceBalls+(4/3)*pi*r(j,1)^3;
        end % End of extracellular-ball placement



        %******************************Write Balls file
        if strcmp(BasicParameters.SaveFiles,'y')
            Filename = sprintf('Balls distribution %s.txt', datetime('now','TimeZone','local','Format','d-MMM-y HH-mm-ss'));
            writematrix([round(xd),  round(yd), round(zd), round(r)],Filename);
        end
        % *****************************



        % Diagnostic only: overlapping sphere volumes are double-counted.
        % Use Monte Carlo Betta below for the actual occupied-space fraction.
        FilledSpace=SpaceBalls/((DistanceX)^3 - (4/3)*pi*Cleft.SynapticEnvelopeRadius^3);


        % Estimate occupied and free extracellular volume by Monte Carlo sampling.
        % Each accepted control point is drawn uniformly from the computational
        % cube but outside the source-specific central exclusion region.
        ControlX = zeros(NumberControlParticles,1);
        ControlY = zeros(NumberControlParticles,1);
        ControlZ = zeros(NumberControlParticles,1);
        PointInsideBall = false(NumberControlParticles,1);

        for ControlIndex = 1:NumberControlParticles
            while true
                ControlX(ControlIndex) = DistanceX*(rand()-0.5);
                ControlY(ControlIndex) = DistanceX*(rand()-0.5);
                ControlZ(ControlIndex) = DistanceX*(rand()-0.5);

                if strcmpi(BasicParameters.ReleaseSource,'synapse')
                    OutsideSourceExclusion = sqrt( ...
                        ControlX(ControlIndex)^2 + ...
                        ControlY(ControlIndex)^2 + ...
                        ControlZ(ControlIndex)^2) > ...
                        Cleft.SynapticEnvelopeRadius;
                else
                    OutsideSourceExclusion = sqrt( ...
                        (ControlX(ControlIndex)-astrocyte_center(1))^2 + ...
                        (ControlY(ControlIndex)-astrocyte_center(2))^2 + ...
                        (ControlZ(ControlIndex)-astrocyte_center(3))^2) > ...
                        astrocyte_radius+Cleft.DistanceAstrocyte;
                end

                if OutsideSourceExclusion
                    break;
                end
            end

            % Stop checking as soon as the point is found inside one ball.
            for BallIndex = FirstExtracellularBallIndex:Numbersphere
                SquaredDistanceToBall = ...
                    (ControlX(ControlIndex)-xd(BallIndex))^2 + ...
                    (ControlY(ControlIndex)-yd(BallIndex))^2 + ...
                    (ControlZ(ControlIndex)-zd(BallIndex))^2;
                if SquaredDistanceToBall < r(BallIndex,1)^2
                    PointInsideBall(ControlIndex) = true;
                    break;
                end
            end
        end

        OccupiedPointCount = sum(PointInsideBall);
        Betta(IterTrial) = OccupiedPointCount/NumberControlParticles;
        AlphaSpace = 1-Betta(IterTrial);

        OccupiedSpacePercent = 100*Betta(IterTrial);
        FreeSpacePercent = 100*AlphaSpace;
        OccupancyStandardError = sqrt( ...
            Betta(IterTrial)*(1-Betta(IterTrial))/NumberControlParticles);
        OccupancyPercentStandardError = 100*OccupancyStandardError;

        fprintf(['Trial %d space occupancy: occupied = %.4f%%, free = %.4f%%, ' ...
            'Monte Carlo SE = %.4f%%, samples = %d\n'], ...
            IterTrial,OccupiedSpacePercent,FreeSpacePercent, ...
            OccupancyPercentStandardError,NumberControlParticles);

        if strcmp(BasicParameters.SaveFiles,'y')
            OccupancySummary = table(IterTrial,NumberControlParticles, ...
                Betta(IterTrial),AlphaSpace,OccupiedSpacePercent, ...
                FreeSpacePercent,OccupancyPercentStandardError, ...
                'VariableNames',{'Trial','SampleCount','OccupiedFraction', ...
                'FreeFraction','OccupiedPercent','FreePercent', ...
                'PercentStandardError'});
            Filename = sprintf('Space Occupancy Trial %d %s.txt', ...
                IterTrial,datetime('now','TimeZone','local', ...
                'Format','d-MMM-y HH-mm-ss'));
            writetable(OccupancySummary,Filename,'Delimiter','tab');

            OccupancyPoints = table(ControlX,ControlY,ControlZ,PointInsideBall, ...
                'VariableNames',{'X_nm','Y_nm','Z_nm','InsideBall'});
            writetable(OccupancyPoints,'particle_data.txt','Delimiter','tab');
        end
        %******************************************************************
        if strcmp(BasicParameters.ShowGraphics,'y')
            hold on;

            % Optional debugging view of the static extracellular obstacles.
            % Each surface is created only once, but a large number of graphics
            % objects can still substantially slow figure interaction.
            if ShowObstacleBalls
                for BallIndex = FirstExtracellularBallIndex:Numbersphere
                    IsAdhesiveBall = r(BallIndex,2) == 1;
                    ShowThisBall = ...
                        strcmp(ObstacleBallDisplayMode,'both') || ...
                        (strcmp(ObstacleBallDisplayMode,'adhesive') && ...
                        IsAdhesiveBall) || ...
                        (strcmp(ObstacleBallDisplayMode,'nonadhesive') && ...
                        ~IsAdhesiveBall);
                    if ~ShowThisBall
                        continue;
                    end

                    if IsAdhesiveBall
                        BallFaceColor = AdhesiveBallColor;
                    else
                        BallFaceColor = NonAdhesiveBallColor;
                    end
                    surf(r(BallIndex,1)*x+xd(BallIndex), ...
                        r(BallIndex,1)*y+yd(BallIndex), ...
                        r(BallIndex,1)*z+zd(BallIndex), ...
                        'FaceColor',BallFaceColor, ...
                        'FaceAlpha',0.18,'EdgeColor','none');
                end
            end

            initialColours = repmat([0.10 0.55 0.95],np,1);
            p_plot = scatter3(x_par(1,:),y_par(1,:),z_par(1,:), ...
                28,initialColours,'filled');

            % Axes were fixed before the source geometry was drawn.
            drawnow;
        end
        % Iteration to store positions of particles
        TimeIter=0;
        InputPar = [np; Numbersphere];
        AverageTimeMatrix = zeros(DistanceBins,TimeBins+1);
        AverageTimeMatrixFree = zeros(DistanceBins,TimeBins+1);

        % Divide the spherical analysis region between the synaptic-cleft
        % radius and the half-width of the cubic domain. The cube is 4000 nm
        % wide, but radial receptor analysis is intentionally limited to
        % 2000 nm from its centre.
        RadialEdges_nm = linspace( ...
            Cleft.RadiusofCleft,SizeCube.AxisSize,DistanceBins+1);
        RadialInnerRadius_um = RadialEdges_nm(1:end-1)'/1000;
        RadialOuterRadius_um = RadialEdges_nm(2:end)'/1000;
        ShellVolume_um3 = (4/3)*pi.*( ...
            RadialOuterRadius_um.^3-RadialInnerRadius_um.^3);
        HistogramTimePoints_ms = ...
            (1:TimeBins)*(TotalTime/TimeBins);

        SnapshotTimes = ComputationSet.SnapshotTimes;
        if ~isvector(SnapshotTimes) || isempty(SnapshotTimes) || ...
                any(~isfinite(SnapshotTimes)) || any(SnapshotTimes <= 0) || ...
                any(diff(SnapshotTimes) <= 0) || any(SnapshotTimes > TotalTime)
            error(['ComputationSet.SnapshotTimes must contain finite, positive, ' ...
                'strictly increasing times not exceeding TotalTime.']);
        end
        SnapshotTimes = reshape(SnapshotTimes,1,[]);
        SnapshotLabels = arrayfun(@(t) sprintf('%g',t), ...
            SnapshotTimes,'UniformOutput',false);
        SnapshotData = cell(size(SnapshotTimes));
        %         Computation in Time

        for i=1:NumberTimeInteraction
            StepStartTime = (i-1)*ComputationSet.GTimeStep;
            CurrentTime = i*ComputationSet.GTimeStep;

            % Activate each scheduled group once, at the start of its first step.
            NewlyReleased = ~HasBeenReleased & ...
                ParticleReleaseTime <= StepStartTime+eps(StepStartTime+1);
            HasBeenReleased(NewlyReleased) = true;
            Stak(NewlyReleased,3) = 1;

            TimeIter=TimeIter+1;
            %     Visualization of calculation in time
            if strcmp(BasicParameters.SaveFiles,'y') && SaveReceptorInputData
                TimeOutPercent = 1/TimeBins;
                if TimeIter == round(TimeOutPercent*TotalTime/ComputationSet.GTimeStep)
                    TimeofDiffusion = i * ComputationSet.GTimeStep;
                    formatSpec = 'Time of diffusion  %8.4f  ms and total time is  %8.4f ms\n';
                    fprintf(formatSpec,TimeofDiffusion, TotalTime);
                    TimeIter=0;
                    if (i == round(CreatMatrixAverage*TotalTime/ComputationSet.GTimeStep))
                        SQBound=zeros(1,BasicParameters.NumberOfParticles);
                        SQFree=zeros(1,BasicParameters.NumberOfParticles);
                        TempNew = (x_par(i,:).^2 + y_par(i,:).^2+ z_par(i,:).^2 ).^0.5;
                        TempNew(TempNew < Cleft.RadiusofCleft)=0;
                        ActiveParticles = Stak(:,3)>0;
                        BoundParticles = (Stak(:,1)>1) & ActiveParticles;
                        FreeParticles = (Stak(:,1)<1.1) & ActiveParticles;
                        SQBound(BoundParticles)=TempNew(BoundParticles);
                        SQFree(FreeParticles)=TempNew(FreeParticles);
                        [NUmm,HSQ] = histcounts(SQBound,RadialEdges_nm);
                        HSQ = HSQ(2:end);
                        [NUmmFree,HSQFree] = histcounts(SQFree,RadialEdges_nm);
                        HSQFree = HSQFree(2:end);
                        %PrintV=[HSQ; NUmm];
                        if CreatMatrixAverage < TimeOutPercent+0.001
                            %(rows, colms)
                            AverageTimeMatrix(1:end,1) = HSQ/1000;
                            AverageTimeMatrix(1:end,2) = NUmm;
                            AverageTimeMatrixFree(1:end,1) = HSQFree/1000;
                            AverageTimeMatrixFree(1:end,2) = NUmmFree;
                        else
                            IndexMatrix=IndexMatrix+1;
                            AverageTimeMatrix(1:end,IndexMatrix+1) = NUmm;
                            AverageTimeMatrixFree(1:end,IndexMatrix+1) = NUmmFree;
                        end
                        CreatMatrixAverage = CreatMatrixAverage+TimeOutPercent;
                    end
                end
            end % visualization

            if strcmp(BasicParameters.SaveFiles,'y')
                snapshotIndex = find(i == round(SnapshotTimes/ComputationSet.GTimeStep),1);
                if ~isempty(snapshotIndex)
                    targetTime = i;
                    StakNew = Stak(:,1);
                    StakNew(StakNew > 1 | Stak(:,3) <= 0) = 0;
                    SnapshotData{snapshotIndex} = [x_par(i,:); y_par(i,:); z_par(i,:); StakNew'];
                end
            end

            % Update the generated extracellular balls independently of the
            % particle loop. The primary astrocyte, when present, is not decayed.
            if Balls.UseAdhesionDecay
                generatedBallIndices = FirstExtracellularBallIndex:Numbersphere;
                adhesiveBallIndices = generatedBallIndices( ...
                    r(generatedBallIndices,2) == 1);
                deactivateMask = ...
                    rand(numel(adhesiveBallIndices),1) < PAdhesionLossStep;
                r(adhesiveBallIndices(deactivateMask),2) = 0;
            end

            TempNumber=0;

            for j=1:np % iteraction np
              if Stak(j,3) > 0 && Stak(j,1) > 1 && rand() < PBoundRemovalStep
                  Stak(j,3) = 0; % irreversible exponential removal of bound glutamate
              end
              if Stak(j,3) > 0
                RadialPosition = sqrt(x_par(i,j)^2+y_par(i,j)^2);
                % A particle is inside the cleft only if it is within the cleft
                % radius AND within the cleft half-width in z. Testing the radius
                % alone mis-classifies particles above/below the synapse
                % (RadialPosition <= cleft radius but |z| large): the cleft
                % z-reflection then throws them far and the solid-volume check
                % reverts the step, freezing them near the envelope.
                InsideSynapticCleft = strcmpi(BasicParameters.ReleaseSource,'synapse') && ...
                    RadialPosition <= Cleft.RadiusofCleft && ...
                    abs(z_par(i,j)) <= Cleft.CleftWidth/2;
                if ~InsideSynapticCleft
                    % Astrocyte release enters this 3D extracellular branch immediately.
                    % Synaptic release enters it after crossing the open radial cleft edge.
                    %  if (sqrt((x_par(i,j))^2)  > 250^2) || (sqrt((y_par(i,j))^2)  > 50^2) || (sqrt((z_par(i,j))^2)  > 50^2)
                    if Stak( j, 1) == 1
                        x_par(i+1,j)=x_par(i,j)+ ComputationSet.StepRad*2*(rand()-0.5);
                        y_par(i+1,j)=y_par(i,j)+ ComputationSet.StepRad*2*(rand()-0.5);
                        z_par(i+1,j)=z_par(i,j)+ ComputationSet.StepRad*2*(rand()-0.5);

                    else
                        x_par(i+1,j)=x_par(i,j);
                        y_par(i+1,j)=y_par(i,j);
                        z_par(i+1,j)=z_par(i,j);
                    end
                    for j_Sphere=1:Numbersphere
                        % Next condition determines the location of a particle that should have entered the ball
                        % but instead remains outside of it. The particle stays in place until it randomly moves away from the ball.
                        % Reflecting a particle from a ball does not work well because the reflection can lead a particle into another ball,
                        % requiring the programme to check the particle's new position each time, resulting in a very large number of checks (infinite calculations)
                        % in the case of a high density of balls.

                        if sqrt((x_par(i+1,j)-xd(j_Sphere))^2+(y_par(i+1,j)-yd(j_Sphere))^2+(z_par(i+1,j)-zd(j_Sphere))^2) < r(j_Sphere,1)
                            if r(j_Sphere,2)==1
                                %************************************************
                                TimeOfAdhesive(j) = TimeOfAdhesive(j) + 1;
                                if Adhesion.MaxProbAdhesive*(1-exp(-(ComputationSet.GTimeStep*TimeOfAdhesive(j))/Adhesion.TimeINsideAdhesiveZone)) > rand()
                                    Stak(j, 1)=Stak(j, 1)+1;
                                    TimeOfAdhesive(j)=0;
                                end
                            end
                            % ComputationSet.StepLocalMovement is a step of
                            % small walking near the ball
                            x_par(i+1,j)=x_par(i,j)+ ComputationSet.StepLocalMovement*ComputationSet.StepRad*2*(rand()-0.5);
                            y_par(i+1,j)=y_par(i,j)+ ComputationSet.StepLocalMovement*ComputationSet.StepRad*2*(rand()-0.5);
                            z_par(i+1,j)=z_par(i,j)+ ComputationSet.StepLocalMovement*ComputationSet.StepRad*2*(rand()-0.5);
                        end
                    end % end of sphere control

                    if Stak(j, 1)  >1
                        Stak(j, 1)=Stak(j, 1)+1;
                    end
                    if Stak(j, 1)  == DigitalTimeofAdhesionStochastic(j) %DigitalTimeofAdhesion
                        Stak(j, 1)=1;
                    end
                    % conditions an open end, which allows to exclude particles
                    % from consideration of the diffusion coefficient if they fly outside the boundary

                else
                    % Quasi-planar Brownian diffusion inside the cylindrical cleft.
                    % The radial edge is open, whereas the two membrane surfaces
                    % confine motion in z by reflection.
                    x_par(i+1,j) = x_par(i,j) + ComputationSet.StepRad*2*(rand()-0.5);
                    y_par(i+1,j) = y_par(i,j) + ComputationSet.StepRad*2*(rand()-0.5);

                    halfCleftWidth = Cleft.CleftWidth/2;
                    zCandidate = z_par(i,j) + ...
                        0.1*ComputationSet.StepRad*2*(rand()-0.5);
                    if zCandidate > halfCleftWidth
                        z_par(i+1,j) = 2*halfCleftWidth-zCandidate;
                    elseif zCandidate < -halfCleftWidth
                        z_par(i+1,j) = -2*halfCleftWidth-zCandidate;
                    else
                        z_par(i+1,j) = zCandidate;
                    end
                end

                % Reject steps into the solid pre- or postsynaptic volume.
                % The equatorial extracellular opening remains accessible.
                if strcmpi(BasicParameters.ReleaseSource,'synapse')
                    candidateDistance = sqrt(x_par(i+1,j)^2 + ...
                        y_par(i+1,j)^2 + z_par(i+1,j)^2);
                    insideSolidSynapticVolume = ...
                        candidateDistance <= Cleft.SynapticEnvelopeRadius && ...
                        abs(z_par(i+1,j)) > Cleft.CleftWidth/2;
                    if insideSolidSynapticVolume
                        x_par(i+1,j) = x_par(i,j);
                        y_par(i+1,j) = y_par(i,j);
                        z_par(i+1,j) = z_par(i,j);
                    end
                end

                % Include active particles that remain inside the computational domain.
                if abs(x_par(i+1,j)) < DistanceX/2 || ...
                        abs(y_par(i+1,j)) < DistanceX/2 || ...
                        abs(z_par(i+1,j)) < DistanceX/2
                    % Use elapsed time since this particle's own release.
                    ParticleAge = CurrentTime-ParticleReleaseTime(j);
                    if ParticleAge > 0
                        DiffusionEstimateSum3D = DiffusionEstimateSum3D + ...
                            (x_par(i+1,j)^2+y_par(i+1,j)^2+z_par(i+1,j)^2) / ...
                            (6*ParticleAge);
                        DiffusionEstimateSumX = DiffusionEstimateSumX + ...
                            x_par(i+1,j)^2/(2*ParticleAge);
                        TempNumber = TempNumber+1;
                    end
                end

                % condition that particles do not fly out of the pipe
                if (sqrt(x_par(i,j)^2+y_par(i,j)^2+z_par(i,j)^2)) > SizeCube.Size/2
                    %                         x_par(i+1,j)=x_par(i-5,j);
                    %                         y_par(i+1,j)=y_par(i-5,j);
                    %                         z_par(i+1,j)=z_par(i-5,j);


                end
              else
                  x_par(i+1,j)=x_par(i,j);
                  y_par(i+1,j)=y_par(i,j);
                  z_par(i+1,j)=z_par(i,j);

              end
            end % iteraction in np

            % Spillover is defined by radial distance from the synapse centre.
            ParticleRadius = sqrt(x_par(i+1,:).^2 + y_par(i+1,:).^2 + z_par(i+1,:).^2);
            ActiveSpilloverParticles = (Stak(:,3)' > 0);
            FreeSpilloverParticles = (Stak(:,1)' == 1);
            SpilloverMask = ActiveSpilloverParticles & ...
                (ParticleRadius >= Cleft.SpilloverRadius);
            FreeSpilloverMask = SpilloverMask & FreeSpilloverParticles;

            NumberSpillover(i+1) = sum(SpilloverMask);
            FractionSpillover(i+1) = NumberSpillover(i+1)/np;
            NumberFreeSpillover(i+1) = sum(FreeSpilloverMask);
            FractionFreeSpillover(i+1) = NumberFreeSpillover(i+1)/np;

            % Record absolute crossing time and latency from individual release.
            NewSpilloverCrossing = isnan(FirstPassageTime) & SpilloverMask;
            FirstPassageTime(NewSpilloverCrossing) = CurrentTime;
            FirstPassageLatency(NewSpilloverCrossing) = ...
                CurrentTime-ParticleReleaseTime(NewSpilloverCrossing)';

            if strcmp(BasicParameters.ShowGraphics,'y') && ...
                    (i == 1 || i == NumberTimeInteraction || mod(i,GraphicsUpdateEvery) == 0)
                activeForDisplay = Stak(:,3)' > 0;
                boundForDisplay = activeForDisplay & (Stak(:,1)' > 1);

                displayX = x_par(i+1,:);
                displayY = y_par(i+1,:);
                displayZ = z_par(i+1,:);
                displayX(~activeForDisplay) = NaN;
                displayY(~activeForDisplay) = NaN;
                displayZ(~activeForDisplay) = NaN;

                particleColours = repmat([0.10 0.55 0.95],np,1);
                particleColours(boundForDisplay,:) = ...
                    repmat([0.95 0.40 0.10],sum(boundForDisplay),1);

                set(p_plot,'XData',displayX,'YData',displayY, ...
                    'ZData',displayZ,'CData',particleColours);
                set(gca,'XLim',[-SizeCube.AxisSize SizeCube.AxisSize], ...
                    'YLim',[-SizeCube.AxisSize SizeCube.AxisSize], ...
                    'ZLim',[-SizeCube.AxisSize SizeCube.AxisSize], ...
                    'XLimMode','manual', ...
                    'YLimMode','manual','ZLimMode','manual');

                currentTime = i*ComputationSet.GTimeStep;
                title(sprintf('%s release | t = %.3f ms | active = %d | bound = %d | beyond %d nm = %d', ...
                    BasicParameters.ReleaseSource,currentTime,sum(activeForDisplay), ...
                    sum(boundForDisplay),Cleft.SpilloverRadius,NumberSpillover(i+1)));
                drawnow limitrate;
            end
            NumberParticles(i+1)=TempNumber;
            TempNumberParticla=TempNumber;
            DifCoef(i+1)=(DiffusionEstimateSum3D/TempNumber)/10^6;
            DifCoefX(i+1)=(DiffusionEstimateSumX/TempNumber)/10^6;
            TempNumber=0;
            DiffusionEstimateSum3D=0;
            DiffusionEstimateSumX=0;
        end % in time

        if strcmp(BasicParameters.SaveFiles,'y')
            for snapshotIndex = 1:numel(SnapshotTimes)
                if ~isempty(SnapshotData{snapshotIndex})
                    Filename = sprintf('PD %s ms %s.txt',SnapshotLabels{snapshotIndex}, ...
                        datetime('now','TimeZone','local','Format','d-MMM-y HH-mm-ss'));
                    fileID = fopen(Filename,'w');
                    fprintf(fileID,'%10.5f %10.5f %10.5f %10.0f \n',SnapshotData{snapshotIndex});
                    fclose(fileID);
                end
            end

            SpilloverOutput = [Time(:), NumberSpillover(:), FractionSpillover(:), ...
                NumberFreeSpillover(:), FractionFreeSpillover(:)];
            Filename = sprintf('Spillover R%d nm Trial %d %s.txt', ...
                Cleft.SpilloverRadius,IterTrial, ...
                datetime('now','TimeZone','local','Format','d-MMM-y HH-mm-ss'));
            writematrix(SpilloverOutput,Filename,'Delimiter','tab');

            FirstPassageOutput = [(1:np)',ParticleReleaseTime, ...
                FirstPassageTime',FirstPassageLatency'];
            Filename = sprintf('Spillover First Passage R%d nm Trial %d %s.txt', ...
                Cleft.SpilloverRadius,IterTrial, ...
                datetime('now','TimeZone','local','Format','d-MMM-y HH-mm-ss'));
            FirstPassageTable = array2table(FirstPassageOutput, ...
                'VariableNames',{'ParticleIndex','ReleaseTime_ms', ...
                'FirstPassageTime_ms','FirstPassageLatency_ms'});
            writetable(FirstPassageTable,Filename,'Delimiter','tab');

            ReleaseScheduleTable = table((1:numel(ReleaseTimes))', ...
                ReleaseTimes',ReleaseFractions',ReleaseCounts', ...
                'VariableNames',{'ReleaseIndex','ReleaseTime_ms', ...
                'RequestedFraction','ParticleCount'});
            Filename = sprintf('Release Schedule Trial %d %s.txt', ...
                IterTrial,datetime('now','TimeZone','local', ...
                'Format','d-MMM-y HH-mm-ss'));
            writetable(ReleaseScheduleTable,Filename,'Delimiter','tab');

            if BasicParameters.Control == 1
                A = [x_par(NumberTimeInteraction+1,:); ...
                     y_par(NumberTimeInteraction+1,:); ...
                     z_par(NumberTimeInteraction+1,:)];
                InputParameters = [charge; Numbersphere];
                fileID = fopen('FinalDistribution.txt','w');
                fprintf(fileID,'%10.5f %10.5f\n',InputParameters);
                fprintf(fileID,'%10.5f %10.5f %10.5f\n',A);
                fclose(fileID);
            end
        end

        DifCoefTotal=DifCoefTotal + DifCoef;
        DifCoefTotalX=DifCoefTotalX + DifCoefX;


        
    end % Trial Number
  

        % Save receptor-input matrices and their exact coordinates using
        % one shared run identifier so downstream analysis can pair them.
        if strcmp(BasicParameters.SaveFiles,'y') && SaveReceptorInputData
            RunID = char(datetime('now','TimeZone','local', ...
                'Format','yyyyMMdd-HHmmss-SSS'));

            DistanceBoundFilename = sprintf( ...
                'DistanceBound %s.txt',RunID);
            DistanceFreeFilename = sprintf( ...
                'DistanceFree %s.txt',RunID);
            MetadataFilename = sprintf( ...
                'SimulationMetadata %s.mat',RunID);

            writematrix(AverageTimeMatrix,DistanceBoundFilename);
            writematrix(AverageTimeMatrixFree,DistanceFreeFilename);

            Metadata = struct;
            Metadata.FormatVersion = 1;
            Metadata.RunID = RunID;
            Metadata.TotalTime_ms = TotalTime;
            Metadata.TimeBins = TimeBins;
            Metadata.DistanceBins = DistanceBins;
            Metadata.TimePoints_ms = HistogramTimePoints_ms;
            Metadata.RadialEdges_nm = RadialEdges_nm;
            Metadata.InnerRadius_um = RadialInnerRadius_um;
            Metadata.OuterRadius_um = RadialOuterRadius_um;
            Metadata.ShellVolume_um3 = ShellVolume_um3;
            Metadata.NumberOfParticles = np;
            Metadata.ReleaseSource = BasicParameters.ReleaseSource;
            Metadata.ReleaseTimes_ms = ReleaseTimes;
            Metadata.ReleaseFractions = ReleaseFractions;
            Metadata.DiffusionCoefficient_nm2_per_ms = ...
                ComputationSet.DifCoefINIT;
            Metadata.BrownianTimeStep_ms = ComputationSet.GTimeStep;
            Metadata.CleftRadius_nm = Cleft.RadiusofCleft;
            Metadata.SynapticEnvelopeRadius_nm = ...
                Cleft.SynapticEnvelopeRadius;
            Metadata.SpilloverRadius_nm = Cleft.SpilloverRadius;
            Metadata.RadialAnalysisLimit_nm = SizeCube.AxisSize;
            Metadata.DistanceFreeFile = DistanceFreeFilename;
            Metadata.DistanceBoundFile = DistanceBoundFilename;

            save(MetadataFilename,'Metadata');
        end
end
% computation of diffusion coefficient
Begin= fix(BeginTime/ComputationSet.GTimeStep);
End=fix(EndTime/ComputationSet.GTimeStep);
MeanDiffusion = mean( DifCoefTotalX(Begin : End));
STDDiffusion = std( DifCoefTotalX(Begin : End));
% end of computation
%     plot(Time, Distance)
%     plot(Time, DifCoefTotalX/TotalNumberinteration)
%     cmap = hsv(np); % Creates a np-by-3 set of colors from the HSV colormap

DiffResults = [MeanDiffusion; STDDiffusion];
fprintf(fileIDStat,'%10.5f %10.5f %10.5f\n', DiffResults, Betta(IterTrial));

  fclose(fileIDStat);
A = [Time;  DifCoefTotalX/TotalNumberinteration; NumberParticles];
InputParameters = [charge; Numbersphere];
Filename = sprintf('Diffusion Set ms% s.txt', datetime('now','TimeZone','local','Format','d-MMM-y HH-mm-ss'));
fileID = fopen(Filename,'w');
fprintf(fileID,'%10.5f %10.5f\n', InputParameters);
fprintf(fileID,'%10.5f %10.5f %10.5f\n', A);
fclose(fileID);










































