function [BasicParameters, Balls, ComputationSet, Cleft, SizeCube, Adhesion, AMPA, NMDA, Analysis]=InputParametersSR()
%INPUTPARAMETERSSR Define all parameters used across the project.
% Single source of parameters for DiffusionGlutamateBalls, Unified_AMPA_SpaceSR,
% and NMDA_SpaceSR_Optimized. Spatial quantities are expressed in nm and
% temporal quantities in ms unless explicitly stated otherwise. No external
% parameter file is required.
%
% Groups: BasicParameters, Balls, ComputationSet, Cleft, SizeCube, Adhesion
%         (diffusion simulation); AMPA, NMDA (receptor drivers); Analysis
%         (shared receptor-analysis constants). Callers may request only the
%         leading groups they need.

% Core simulation parameters
np = 50;                         % number of released particles
Trials = 1;                        % number of independent simulation trials
MaxProbAdhesive = 1.0;             % maximum probability of adhesion
TimeINsideAdhesiveZone = 1.0;      % ms, adhesion time constant
ProbabilityofAstrocytes = 0.1;     % fraction of balls with astrocytic adhesion
Numbersphere = 1500;               % number of spherical extracellular obstacles
UnboundProb = 0.0;                 % probability that an adhered particle can later unbind


% ************************************************************************
SizeCube.Size = 4000; % nm, side length of the cubic computational domain
% The half-size is used for graphics limits and open-boundary checks.
SizeCube.AxisSize=SizeCube.Size/2; % nm, half-width of the computational domain
%***************************************************************************
% Release, run-control, output, and visualisation parameters
BasicParameters.SaveFiles = 'y'; % y writes result files; n keeps results in memory only
BasicParameters.SaveReceptorInputData = true; % save DistanceFree, DistanceBound, and matching SimulationMetadata files
BasicParameters.ShowGraphics = 'y'; % y enables particle dynamics; n gives maximum simulation speed
BasicParameters.ShowObstacleBalls = true; % true draws extracellular balls for debugging; this can be very slow
BasicParameters.ObstacleBallDisplayMode = 'adhesive'; % allowed values: 'adhesive', 'nonadhesive', or 'both'
BasicParameters.AdhesiveBallColor = [0.90 0.15 0.10]; % RGB colour of adhesive extracellular balls
BasicParameters.NonAdhesiveBallColor = [0.20 0.45 0.85]; % RGB colour of non-adhesive extracellular balls
BasicParameters.GraphicsUpdateEveryNSteps = 1000; % positive integer; 1000 steps = 0.1 ms with the default time step
BasicParameters.ReleaseSource = 'synapse'; % allowed values: 'astrocyte' or 'synapse'
BasicParameters.ReleaseTimes = [0, 4]; % ms, strictly increasing particle-release times
BasicParameters.ReleaseFractions = [0.5, 0.5]; % fraction of all particles assigned to each release
BasicParameters.AstrocyteRadius = 300; % nm, radius of the primary release astrocyte
BasicParameters.AstrocyteCenterDistance = 300; % nm, distance from the release origin to the astrocyte centre
BasicParameters.ReleasePatchRadius = 100; % nm, radius of the astrocytic release patch

BasicParameters.NumberOfParticles = np; % total particles distributed across all scheduled releases

BasicParameters.charge = 0; % retained metadata field; particle motion is currently uncharged
BasicParameters.TotalTime = 8; % ms, total simulated time
BasicParameters.Numbersphere = Numbersphere; % total rows available for real source geometry and extracellular balls
BasicParameters.UnboundProb = UnboundProb;
% 0.2	1400 26 January 2023
% 0.3	1120
% 0.4	850
% 0.5	600
BasicParameters.BeginTime = 0.8; % fraction of TotalTime at which diffusion analysis begins
BasicParameters.EndTime = 0.9; % fraction of TotalTime at which diffusion analysis ends
BasicParameters.Trials = Trials; % number of independent Monte Carlo trials
BasicParameters.Control = 2; % set to 1 to save FinalDistribution.txt
BasicParameters.UseExponentialDecay = true; % irreversible removal of bound glutamate
BasicParameters.TimeDecay = 8; % ms, exponential time constant for bound-particle removal


% Extracellular-ball geometry, placement, occupancy, and adhesion-state parameters
Balls.name = 'Balls';
Balls.MaxBallRadius = 400.0; % nm, maximum random-ball radius
Balls.MinBallRadius = 50.0; % nm, minimum random-ball radius
Balls.BettaControl = 0.8; % legacy target occupied fraction; not used to adjust placement
Balls.PlacementMode = 'overlapping'; % allowed values: 'overlapping' or 'nonoverlapping'; overlapping is the standard mode
Balls.MinimumBallSeparation = 0.1; % nm, minimum surface-to-surface distance used only in nonoverlapping mode
Balls.MaximumPlacementAttempts = 100000; % maximum attempts to place each ball before stopping with an error
Balls.OccupancySampleCount = 100000; % number of Monte Carlo points used to estimate occupied and free space
Balls.UseAdhesionDecay = true; % enables irreversible loss of extracellular-ball adhesiveness
Balls.AdhesionDecayTime = 1000; % ms, exponential time constant of adhesiveness loss
Balls.ProbabilityofAstrocytes=ProbabilityofAstrocytes; % fraction of accepted balls initially marked adhesive

% *************************************************************************
% Brownian-motion, sampling, and output-resolution parameters
ComputationSet.DifCoefINIT=(0.4*10^6); % nm^2/ms, equivalent to 0.4 um^2/ms
ComputationSet.GTimeStep=0.0001; % ms, Brownian integration time step
ComputationSet.StepRad=sqrt(6*ComputationSet.DifCoefINIT * ComputationSet.GTimeStep); % nm, 3D RMS Brownian step
ComputationSet.StepLocalMovement=0.1; % zero step-distance fluctuation in proportion to StepRad
ComputationSet.DistanceBins=100; % number of radial bins in bound/free distance histograms
ComputationSet.TimeBins=100; % number of equally spaced histogram sampling intervals over TotalTime
ComputationSet.SnapshotTimes=[0.1, 0.3, 1.0, 3.0]; % ms, particle-distribution snapshot times


% *************************************************************************
% Computational-domain and synaptic-geometry parameters
Cleft.RadiusofCleft=100; % nm, radius of the cylindrical synaptic cleft
Cleft.CleftWidth=10; % nm, total separation between the two cleft membranes
Cleft.DistanceAstrocyte = 10; % nm, clearance between the synaptic envelope and extracellular obstacles
Cleft.SynapticEnvelopeRadius = 110; % nm, radius of the central pre/postsynaptic exclusion sphere
Cleft.SpilloverRadius = 300; % nm, radial distance from the release origin defining spillover or extracellular spread

%**************************************************************************
% Particle adhesion and de-adhesion kinetics
Adhesion.TimeOfDeAdhesion = 4; % ms, legacy deterministic de-adhesion time
%Adhesion.MaxProbAdhesive =0.3; %1 = instant adhesion 0 = non-adhesion
Adhesion.MaxProbAdhesive =MaxProbAdhesive; % asymptotic probability scale: 1 adhesive, 0 non-adhesive
Adhesion.TimeINsideAdhesiveZone =TimeINsideAdhesiveZone; % ms, binding time constant inside an adhesive ball
%Adhesion.TimeINsideAdhesiveZone =0.001; % Number of steps to reach half of the maximum adhesion is TimeINsideAdhesiveZone/StepRad
                                        % for 0.001 => 160 steps
                                        % ms is the constant of the time spent 
                                        % in the zone of the transporters necessary for the glutamate to bind to the transporters. 
                                        % The shorter the time, the better the connection.

% ProbabilityToStuck=0.4;
% DistanceofAdhesion = ProbabilityToStuck*160*ComputationSet.StepRad; % um
% Adhesion.RandomNumber =1 - DistanceofAdhesion;

%**************************************************************************
% Shared receptor-analysis constants (used by both receptor drivers)
Analysis.AvogadroNumber   = 6.02214076e23; % /mol
Analysis.DataFolderName   = 'SA10Psi01N5000D04Time25msUp0ms'; % folder with DistanceFree/SimulationMetadata (NMDA driver)
Analysis.ODE_RelTol       = 1e-8;  % relative tolerance for the receptor ODE solvers
Analysis.ODE_AbsTol       = 1e-7;  % per-state absolute tolerance (non-stiff models: AMPA, AMPA1, NMDA)
Analysis.ODE_AbsTol_Stiff = 1e-12; % per-state absolute tolerance (stiff AMPA2 solved with ode15s)

%**************************************************************************
% AMPA spatial-analysis parameters (used by Unified_AMPA_SpaceSR)
AMPA.TimeGlu_ms       = BasicParameters.TotalTime;    % ms, glutamate input duration (linked to master TotalTime)
AMPA.BinGlu           = ComputationSet.DistanceBins;  % number of radial shells (linked to DistanceBins)
AMPA.TotalTime_ms     = 200;   % ms, ODE integration horizon for the AMPA dynamics
AMPA.OutputTimeStep_ms = 0.25; % ms, temporal resolution of the saved AMPA response grid
AMPA.MaxDistance_um   = 2;     % um, radial plotting range

%**************************************************************************
% NMDA spatial-analysis parameters (used by NMDA_SpaceSR_Optimized)
NMDA.TotalTime_ms             = 200; % ms, total duration of the NMDA receptor dynamics
NMDA.LegacyMasterTotalTime_ms = 25;  % ms, master duration used only when SimulationMetadata is absent
NMDA.LegacyMaximumDistance_um = 2;   % um, plotting range used only for legacy data

end




















