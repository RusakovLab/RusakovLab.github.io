% Run the AMPA models one after another, pausing to ask before each next one.

models = {'AMPA', 'AMPA1', 'AMPA2'};

for k = 1:numel(models)
    fprintf('\n=== Running %s ===\n', models{k});
    Unified_AMPA_SpaceSR(models{k});

    % After each model (except the last), ask whether to continue.
    if k < numel(models)
        answer = questdlg(sprintf('Finished %s. Run %s next?', models{k}, models{k+1}), ...
                          'Continue?', 'Yes', 'No', 'Yes');
        if ~strcmp(answer, 'Yes')
            fprintf('Stopped after %s.\n', models{k});
            break;
        end
    end
end
