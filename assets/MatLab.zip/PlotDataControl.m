% PlotDataControl - visualize Monte-Carlo particle (glutamate) positions.
%
% Reads all 'PD 3 *.txt' files in the current folder (one per seed / attempt;
% expect >= 10 of them). Each file holds particle records with columns
% [X, Y, Z, State], where State = 1 (Free) or State = 0 (Bound).
%
% Only the "real diffusion" region is shown: particles whose X, Y and Z all
% lie within +/- Lim nm. The script plots the selected particles as a 3D
% cloud:
%   figure 1 - all files combined
%   figure 2 - the last file only

% close all;
% clear;

BinGlu = 4;          % number of columns per record: [X, Y, Z, State]
Lim    = 2000;       % half-size of the diffusion box shown (nm)

% State flags in the 4th column
Free  = 1;
Bound = 0;
StateParticle = Free;

% --- Locate input files ---------------------------------------------------
myFolder = pwd;
if ~isfolder(myFolder)
    errorMessage = sprintf('Error: The following folder does not exist:\n%s', myFolder);
    uiwait(warndlg(errorMessage));
    return;
end

filePattern = fullfile(myFolder, 'PD 3 *.txt');   % change pattern if needed
theFiles = dir(filePattern);
NumberOfFiles = length(theFiles);
if NumberOfFiles == 0
    warning('No files matching "%s" were found.', filePattern);
    return;
end

% --- Read and stack all files (one per seed) ------------------------------
TotalSumMatrix = [];        % grows to (sum of rows) x BinGlu
lastFile = [];              % keeps the most recently read file

for K = 1:NumberOfFiles
    baseFileName = theFiles(K).name;
    fullFileName = fullfile(myFolder, baseFileName);
    fprintf(1, 'Now reading %s\n', fullFileName);

    output = load(fullFileName);            % ASCII numeric matrix
    TotalSumMatrix = [TotalSumMatrix; output]; %#ok<AGROW>
    lastFile = output;
end

% Helper: keep the requested state AND only points inside the +/-Lim box.
inBox = @(M) M(M(:,4) == StateParticle & ...
               abs(M(:,1)) <= Lim & abs(M(:,2)) <= Lim & abs(M(:,3)) <= Lim, :);

% --- Figure 1: selected particles across ALL files -----------------------
sel1 = inBox(TotalSumMatrix);
figure(1);
scatter3(sel1(:,1), sel1(:,2), sel1(:,3), 'filled', ...
         'MarkerFaceAlpha', 0.2, 'MarkerEdgeAlpha', 0.2);
xlabel('X (nm)'); ylabel('Y (nm)'); zlabel('Z (nm)');
title(sprintf('Diffusion cloud - all files (n = %d)', size(sel1,1)));
grid on; axis equal;
xlim([-Lim, Lim]); ylim([-Lim, Lim]); zlim([-Lim, Lim]);

% --- Figure 2: selected particles from the LAST file only ----------------
sel2 = inBox(lastFile);
figure(2);
scatter3(sel2(:,1), sel2(:,2), sel2(:,3), 'filled', ...
         'MarkerFaceAlpha', 0.2, 'MarkerEdgeAlpha', 0.2);
xlabel('X (nm)'); ylabel('Y (nm)'); zlabel('Z (nm)');
title(sprintf('Diffusion cloud - last file (n = %d)', size(sel2,1)));
grid on; axis equal;
xlim([-Lim, Lim]); ylim([-Lim, Lim]); zlim([-Lim, Lim]);

% --- Figure 3: Bound vs Free (all files), coloured by state --------------
% Keep only the +/-Lim box, then split by state.
boxRows   = abs(TotalSumMatrix(:,1)) <= Lim & ...
            abs(TotalSumMatrix(:,2)) <= Lim & ...
            abs(TotalSumMatrix(:,3)) <= Lim;
inBoxAll  = TotalSumMatrix(boxRows, :);
boundPts  = inBoxAll(inBoxAll(:,4) == Bound, :);
freePts   = inBoxAll(inBoxAll(:,4) == Free,  :);

figure(3);
scatter3(boundPts(:,1), boundPts(:,2), boundPts(:,3), 18, 'filled', ...
         'MarkerFaceColor', [0.2 0.4 0.8], 'MarkerFaceAlpha', 0.15, 'MarkerEdgeAlpha', 0.15);
hold on;
scatter3(freePts(:,1), freePts(:,2), freePts(:,3), 30, 'filled', ...
         'MarkerFaceColor', [0.85 0.15 0.15], 'MarkerFaceAlpha', 0.9);
hold off;
xlabel('X (nm)'); ylabel('Y (nm)'); zlabel('Z (nm)');
title('Bound vs Free - all files');
legend(sprintf('Bound (n = %d)', size(boundPts,1)), ...
       sprintf('Free (n = %d)',  size(freePts,1)), 'Location', 'northeast');
grid on; axis equal;
xlim([-Lim, Lim]); ylim([-Lim, Lim]); zlim([-Lim, Lim]);
