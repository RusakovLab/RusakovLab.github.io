function Unified_AMPA_SpaceSR(model_type)
% Unified version of AMPA_SpaceSR, AMPA1_SpaceSR, and AMPA2_SpaceSR
% Input: model_type - 'AMPA', 'AMPA1', or 'AMPA2' (defaults to 'AMPA')

% Default to the basic AMPA model when called with no argument.
if nargin < 1 || isempty(model_type)
    model_type = 'AMPA';
end

% All parameters come from the shared InputParametersSR definition.
% (Group named AmpaPar here to avoid clashing with the @AMPA function handle.)
[~, ~, ComputationSet, ~, ~, ~, AmpaPar, ~, Analysis] = InputParametersSR();

TimeGlu = AmpaPar.TimeGlu_ms;                   % ms, glutamate input duration (= master TotalTime)
BinGlu = AmpaPar.BinGlu;                        % number of radial shells (= DistanceBins)
OutputTimeStep_ms = AmpaPar.OutputTimeStep_ms;  % temporal resolution of saved AMPA dynamics
timeCalculus = AmpaPar.TotalTime_ms;            % ODE integration horizon (ms)
MaxDistance_um = AmpaPar.MaxDistance_um;        % radial plotting range (um)
DistanceReal = (1:1:BinGlu+1)*(1/BinGlu);
InitialDistribution = zeros(BinGlu, ComputationSet.TimeBins + 1);

% Set model-specific parameters
switch model_type
    case 'AMPA'
        ode_function = @AMPA;
        initial_conditions = [1 0 0 0 0 0];
        desens_calc = @(Y) Y(:, 4) + Y(:, 5);
        open_calc = @(Y) Y(:, 6);
        desens_clim = [0, 1];
        open_clim = [0, 1];
    case 'AMPA1'
        ode_function = @AMPA1;
        initial_conditions = [1 0 0 0 0 0];
        desens_calc = @(Y) Y(:, 4);
         open_calc = @(Y) Y(:, 5)+Y(:, 6);
        desens_clim = [0, 1];
        open_clim = [0, 0.5];
    case 'AMPA2'
        ode_function = @AMPA2;
        initial_conditions = [1 0 0 0 0 0 0 0 0 0 0 0];
        desens_calc = @(Y) Y(:, 9) + Y(:, 10) + Y(:, 11) + Y(:, 12);
        open_calc = @(Y) Y(:, 6) + Y(:, 7) + Y(:, 8);
        desens_clim = [0, 1]; % Adjust if needed
        open_clim = [0, 1]; % Adjust if needed
    otherwise
        error('Invalid model type. Use ''AMPA'', ''AMPA1'', or ''AMPA2''');
end

% Load and process data files
myFolder = pwd;
if ~isfolder(myFolder)
    errorMessage = sprintf('Error: The following folder does not exist:\n%s', myFolder);
    uiwait(warndlg(errorMessage));
    return;
end

filePattern = fullfile(myFolder, 'DistanceFree*.txt');
theFiles = dir(filePattern);
for K = 1:length(theFiles)
    baseFileName = theFiles(K).name;
    fullFileName = fullfile(myFolder, baseFileName);
    fprintf(1, 'Now reading %s\n', fullFileName);
    thisStructure = load(fullFileName);
    output = thisStructure;
    InitialDistribution = InitialDistribution + output;
end
InitialDistribution = InitialDistribution/length(theFiles);

% Calculate glutamate concentration in uM (this value is fed directly to the ODE)
Volume = ((4/3) * pi * ((2 * DistanceReal(2:end)').^3 - (2 * DistanceReal(1:end-1)').^3));
ConcentrationOneMolecules = 1.66 * 10^-6; % mM produced by one molecule per unit volume
Con = (1000)*ConcentrationOneMolecules;   % same amount expressed in uM (1 mM = 1000 uM)
InitialDistribution(:, 2:end) = Con*InitialDistribution(:, 2:end) ./ Volume;

% Plot glutamate concentration
figure(1)
contourf(log(InitialDistribution(:, 2:end)), 10, 'LineColor', 'none')
colorbar
clim([-8,4.5]);
ax = gca;
ax.XTick = linspace(1, size(InitialDistribution(:, 2:end), 2), 5);
ax.XTickLabel = linspace(0, TimeGlu, 5);
ax.YTick = linspace(1, size(InitialDistribution(:, 2:end), 1), 5);
ax.YTickLabel = linspace(0, MaxDistance_um, 5);
xlabel('Time (ms)')
ylabel('Distance (um)')
title('Glu concentration')

% Differential AMPA Analysis
BinTotal = round(BinGlu*timeCalculus/TimeGlu); 
AMPATimeBin = linspace(0, timeCalculus, BinTotal);
% Preallocate the extended glutamate input.
GluTotal = zeros(1, BinTotal);

% Set ODE solver + options based on model type.
% AMPA2 is mildly stiff (rate spread ~0.008..8 /ms); the stiff solver ode15s
% takes far fewer steps than ode45 forced to MaxStep 0.1. The previous
% ultra-tight settings are kept commented below for reference / rollback.
if strcmp(model_type, 'AMPA2')
    ode_solver = @ode15s;
    options = odeset('RelTol', Analysis.ODE_RelTol, 'AbsTol', Analysis.ODE_AbsTol_Stiff, 'NonNegative', 1:12);
    % Original (very slow):
    % options = odeset('RelTol',1e-12,'AbsTol',1e-20,'NonNegative',1:12,'Refine',10,'MaxStep',0.1);
else
    ode_solver = @ode45;
    options = odeset('RelTol', Analysis.ODE_RelTol, 'AbsTol', Analysis.ODE_AbsTol*ones(1, length(initial_conditions)));
end

% Sample the complete AMPA simulation at a fixed temporal resolution.
% Changing timeCalculus automatically updates the number of saved points.
sampleTimes = 0:OutputTimeStep_ms:timeCalculus;
if sampleTimes(end) < timeCalculus
    sampleTimes(end+1) = timeCalculus;
end
OutputTimeBinCount = numel(sampleTimes);
TwoBount = zeros(BinGlu, OutputTimeBinCount);
Open = zeros(BinGlu, OutputTimeBinCount);
distance_points = linspace(0, MaxDistance_um, BinGlu);

% Ask the solver for output on a dense grid spanning the FULL horizon
% (0..timeCalculus) so Figure 2 shows the whole computation; TwoBount/Open
% are then read off at sampleTimes. Providing a fixed output grid does not
% change the solver's internal step size or its accuracy.
plotTimes = linspace(0, timeCalculus, 400);

% Overlaying all 100 traces live is a major graphics bottleneck; off by default.
plotTraces = false;
if plotTraces
    figure(4); hold on;
end

% Main processing loop
for Jitter = 1:BinGlu
    fprintf('Processing iteration %d of %d\n', Jitter, BinGlu);
    TestGlu = InitialDistribution(Jitter, 2:end);

    if numel(TestGlu) < BinTotal
        TestGlu(BinTotal) = 0;
    else
        TestGlu = TestGlu(1:BinTotal);
    end

    current_ode = @(t, y) ode_function(t, y, TestGlu', AMPATimeBin, timeCalculus);
    [T, Y] = ode_solver(current_ode, plotTimes, initial_conditions, options);

    Desensitization = desens_calc(Y);
    OpenState       = open_calc(Y);
    TwoBount(Jitter, :) = interp1(T, Desensitization, sampleTimes);
    Open(Jitter, :)     = interp1(T, OpenState, sampleTimes);

    if plotTraces
        plot(T, Desensitization);
    end
end

if plotTraces
    hold off;
    title('Desensitization States');
    xlabel('Time');
    ylabel('Desensitization');
end

% Plot state variables
figure(2);
num_states = length(initial_conditions);
for i = 1:num_states
    subplot(2, ceil(num_states/2), i);
    plot(T, Y(:,i));
    title(['State ' num2str(i)]);
end

% Plot desensitization state
figure(3)
contourf(sampleTimes, distance_points, TwoBount, 20, 'LineColor', 'none')
colorbar
clim(desens_clim);
xlabel('Time (ms)')
ylabel('Distance (um)')
title([model_type ' desensitization state'])

% Plot open state (color scale adapts to the actual response maximum)
figure(6)
contourf(sampleTimes, distance_points, Open, 20, 'LineColor', 'none')
colorbar
openMax = max(Open(:), [], 'omitnan');
if ~isfinite(openMax) || openMax <= 0
    openMax = 1;   % fallback for an all-zero / empty response
end
clim([0, openMax]);
xlabel('Time (ms)')
ylabel('Distance (um)')
title([model_type ' Open state'])

% Save data in ORIGIN format with model_type in filename
% Create time and distance vectors for headers
time_points = sampleTimes;

% Save TwoBount data
desens_filename = sprintf('%s_Desensitization_State.dat', model_type);
fid = fopen(desens_filename, 'w');
% Write header line with time points
%fprintf(fid, 'Distance (um)\t');
%fprintf(fid, '%f\t', time_points(1:end-1));
%fprintf(fid, '%f\n', time_points(end));
% Write data
for i = 1:size(TwoBount, 1)
    %fprintf(fid, '%f\t', distance_points(i));
    fprintf(fid, '%f\t', TwoBount(i, 1:end-1));
    fprintf(fid, '%f\n', TwoBount(i, end));
end
fclose(fid);

% Save Open data
open_filename = sprintf('%s_Open_State.dat', model_type);
fid = fopen(open_filename, 'w');
% Write header line with time points
% fprintf(fid, 'Distance (um)\t');
% fprintf(fid, '%f\t', time_points(1:end-1));
% fprintf(fid, '%f\n', time_points(end));
% Write data
for i = 1:size(Open, 1)
    %fprintf(fid, '%f\t', distance_points(i));
    fprintf(fid, '%f\t', Open(i, 1:end-1));
    fprintf(fid, '%f\n', Open(i, end));
end
fclose(fid);

disp('Data saved in ORIGIN format:');
disp(['  - ' desens_filename]);
disp(['  - ' open_filename]);
end




