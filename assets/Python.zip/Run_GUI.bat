@echo off
setlocal
REM ============================================================
REM  Launch the Glutamate Diffusion & Receptor Kinetics GUI
REM  Put this file in the same folder as gui.py, then double-click.
REM ============================================================

cd /d "%~dp0"
echo Starting Glutamate GUI...
echo Folder: %cd%
echo.

REM --- Your Python (Anaconda) ---
set "PYEXE=C:\Users\savtc\anaconda3\python.exe"

REM Fallbacks in case the path above ever changes
if not exist "%PYEXE%" if exist "%USERPROFILE%\anaconda3\python.exe"  set "PYEXE=%USERPROFILE%\anaconda3\python.exe"
if not exist "%PYEXE%" if exist "%USERPROFILE%\Anaconda3\python.exe"  set "PYEXE=%USERPROFILE%\Anaconda3\python.exe"
if not exist "%PYEXE%" where python >nul 2>nul && set "PYEXE=python"

if not exist "%PYEXE%" if "%PYEXE%" neq "python" (
    echo *** Python not found at the expected path. ***
    echo Run Find_Python.bat again and send me the path.
    echo.
    pause
    exit /b 1
)

echo Using Python: %PYEXE%
echo.
"%PYEXE%" gui.py

if %errorlevel% neq 0 (
    echo.
    echo *** The program exited with an error ^(code %errorlevel%^). ***
    echo If a module is missing, run:
    echo     "%PYEXE%" -m pip install -r requirements.txt
    echo.
    pause
)
endlocal
