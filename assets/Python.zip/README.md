# Stochastic Synapse Neuroalgebra — Python port

Python translation of the MATLAB project (glutamate diffusion + NMDA/AMPA
receptor kinetics), organised as a clean layered package so the three stages
share one parameter source and can later be combined behind one interface.

## Layout

```
Claude/
  glutamate/
    config.py          # single parameter source (port of InputParametersSR.m)
    kinetics.py        # AMPA / AMPA1 / AMPA2 / NMDA ODE right-hand sides
    concentration.py   # molecule counts -> uM
    diffusion.py       # Monte Carlo glutamate simulation (DiffusionGlutamateBalls.m)
    receptors_ampa.py  # spatial AMPA driver (Unified_AMPA_SpaceSR.m)
    receptors_nmda.py  # spatial NMDA driver (NMDA_SpaceSR_Optimized.m)
    plotting.py        # figures, separate from computation
    io_files.py        # read/write DistanceFree / metadata / snapshot files
  run.py               # command-line entry points
  tests/               # numerical + smoke tests
  requirements.txt
```

## Install & test

```bash
pip install -r requirements.txt
python tests/test_kinetics.py         # conservation, relaxation, concentration
python tests/test_diffusion_smoke.py  # tiny end-to-end Monte Carlo
```

## GUI (for students & graduate students)

A desktop app built on Tkinter (ships with Python — no extra install) with an
embedded matplotlib canvas:

```bash
python gui.py
```

Workflow: edit parameters in the left panel (or click **Quick preset** for a fast
run), press **Run diffusion**, then **Run AMPA/AMPA1/AMPA2** or **Run NMDA** on the
result, and switch the view (Concentration / Open state / Desensitization /
Spillover / Particles). Long runs execute in a background thread with a progress
bar, and **Save results...** writes DistanceFree/Bound, metadata and snapshots.

## Command line

```bash
python run.py diffusion --out results/run1     # Monte Carlo -> DistanceFree/Bound + metadata
python run.py ampa  --data results/run1 --model AMPA2
python run.py nmda  --data results/run1
python run.py all   --out results/run1         # diffusion, then all receptor models
```

All parameters come from `glutamate.config.default_config()`. As in the MATLAB
`InputParametersSR.m`, the AMPA glutamate duration and shell count are linked to
the diffusion parameters (`ampa.TimeGlu_ms = basic.TotalTime`,
`ampa.BinGlu = computation.DistanceBins`). Pass `--seed` for reproducibility.

## Correspondence with the MATLAB code

| MATLAB | Python |
|--------|--------|
| `InputParametersSR.m` | `glutamate/config.py` |
| `AMPA.m`, `AMPA1.m`, `AMPA2.m`, `NMDA_basic.m` | `glutamate/kinetics.py` |
| `Unified_AMPA_SpaceSR.m` | `glutamate/receptors_ampa.py` |
| `NMDA_SpaceSR_Optimized.m` | `glutamate/receptors_nmda.py` |
| `DiffusionGlutamateBalls.m` | `glutamate/diffusion.py` |
| `PlotDataControl.m` + figures | `glutamate/plotting.py` |

## Units and receptor input contract

Concentration handed to the kinetics is in **uM** (`1e21 / N_A ≈ 1.66e-3` uM per
molecule per um³). Effective binding coefficients acting on that uM input:
AMPA 13, AMPA1 13, AMPA2 20, NMDA 25 (/uM/ms) — consistent across models. All
four kinetic schemes conserve total receptor probability (checked in tests).

## Notes / fidelity

- The kinetics are exact ports (verified: probability conserved to ~1e-15,
  relaxation to the unbound state, concentration constant).
- The diffusion Monte Carlo is a **statistically faithful, vectorized** port
  (NumPy KD-tree for obstacle containment). Because NumPy and MATLAB use
  different RNGs it is not bit-identical; observables match in distribution.
- `SimulationMetadata` is written as JSON here; the NMDA driver reads MATLAB
  `.mat` metadata when present (via `scipy.io`) and otherwise falls back to the
  legacy shell geometry.
- Full-scale defaults (500 particles, 1500 obstacles, 8 ms, 0.1 µs step) are
  heavy; use a reduced config for quick runs, as in the smoke test.

## Status

The stages are combined behind one `Config`-driven interface and a Tkinter GUI
(`gui.py`). The computational functions return result objects and never require
the working directory, so the GUI is a thin control layer over tested code.

Possible next steps: parameter save/load (JSON), a run manifest, and diffusion-
level tests (Brownian coefficient recovery, particle accounting, spillover
first-passage ordering).
