"""Read/write the project's data files (kept separate from computation).

Mirrors the DistanceFree / DistanceBound / SimulationMetadata / PD snapshot
outputs of DiffusionGlutamateBalls.m so the Python and MATLAB pipelines can
exchange data.
"""
from __future__ import annotations

import json
import os
from datetime import datetime

import numpy as np


def _timestamp() -> str:
    return datetime.now().strftime("%Y%m%d-%H%M%S-%f")[:-3]


def save_receptor_input(result, folder: str) -> dict:
    """Write DistanceFree/DistanceBound matrices + metadata JSON. Returns paths."""
    os.makedirs(folder, exist_ok=True)
    run_id = _timestamp()
    free_path = os.path.join(folder, f"DistanceFree {run_id}.txt")
    bound_path = os.path.join(folder, f"DistanceBound {run_id}.txt")
    np.savetxt(free_path, result.average_free, fmt="%.6g")
    np.savetxt(bound_path, result.average_bound, fmt="%.6g")

    meta = dict(result.metadata)
    meta["RunID"] = run_id
    meta["DistanceFreeFile"] = os.path.basename(free_path)
    meta["DistanceBoundFile"] = os.path.basename(bound_path)
    meta_path = os.path.join(folder, f"SimulationMetadata {run_id}.json")
    with open(meta_path, "w") as fh:
        json.dump({k: (v.tolist() if isinstance(v, np.ndarray) else v)
                   for k, v in meta.items()}, fh, indent=2)
    return {"free": free_path, "bound": bound_path, "metadata": meta_path}


def save_snapshots(result, folder: str) -> list:
    os.makedirs(folder, exist_ok=True)
    paths = []
    for label, arr in result.snapshots.items():
        path = os.path.join(folder, f"PD {label} ms {_timestamp()}.txt")
        # columns: X Y Z State  (rows = particles)
        np.savetxt(path, arr.T, fmt="%10.5f %10.5f %10.5f %10.0f")
        paths.append(path)
    return paths


def load_distance_matrix(path: str) -> np.ndarray:
    return np.loadtxt(path)
