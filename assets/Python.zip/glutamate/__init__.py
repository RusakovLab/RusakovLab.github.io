"""Stochastic Synapse Neuroalgebra -- glutamate diffusion and receptor kinetics.

Layered Python package:
  config          - single parameter source (port of InputParametersSR.m)
  kinetics        - AMPA/AMPA1/AMPA2/NMDA ODE right-hand sides
  concentration   - molecule counts -> uM
  diffusion       - Monte Carlo glutamate simulation
  receptors_ampa  - spatial AMPA driver (Unified_AMPA_SpaceSR.m)
  receptors_nmda  - spatial NMDA driver (NMDA_SpaceSR_Optimized.m)
  plotting        - figures, separate from computation
  io_files        - read/write DistanceFree / metadata / snapshot files
"""
from .config import Config, default_config

__all__ = ["Config", "default_config"]
__version__ = "0.1.0"
