@echo off
setlocal enabledelayedexpansion
REM ============================================================
REM  Find every python.exe on this computer and print its path.
REM  Double-click, wait, then copy the path it prints.
REM ============================================================

echo Searching for python.exe ... this can take a minute.
echo.

set "FOUND="

REM Quick checks first (PATH + common install spots)
for %%P in (python.exe) do (
    for /f "delims=" %%I in ('where %%P 2^>nul') do (
        echo FOUND: %%I
        set "FOUND=1"
    )
)

for %%D in (
    "%USERPROFILE%\anaconda3\python.exe"
    "%USERPROFILE%\miniconda3\python.exe"
    "%USERPROFILE%\Anaconda3\python.exe"
    "%LOCALAPPDATA%\Programs\Python"
    "C:\ProgramData\Anaconda3\python.exe"
    "C:\ProgramData\miniconda3\python.exe"
) do (
    if exist "%%~D" echo FOUND: %%~D & set "FOUND=1"
)

echo.
echo Scanning drives C: and E: for any other python.exe ...
for /f "delims=" %%I in ('dir /b /s "C:\python.exe" 2^>nul') do echo FOUND: %%I & set "FOUND=1"
for /f "delims=" %%I in ('dir /b /s "E:\python.exe" 2^>nul') do echo FOUND: %%I & set "FOUND=1"

echo.
if not defined FOUND (
    echo No python.exe found automatically.
    echo Open Spyder and run:  import sys; print(sys.executable^)
    echo then send me that line.
) else (
    echo ------------------------------------------------------------
    echo Copy one of the FOUND paths above and send it to me,
    echo or paste it into Run_GUI.bat as:  set "PYEXE=that\path\python.exe"
)
echo.
pause
endlocal
